﻿//SimStateDudes - Sim State - Core Module
using System;
using System.Collections.Generic;
using Sims3.Gameplay;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.Autonomy;
using Sims3.Gameplay.CAS;
using Sims3.Gameplay.Core;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Objects;
using Sims3.Gameplay.Utilities;
using Sims3.SimIFace;
using Sims3.SimIFace.Enums;
using Sims3.UI;
using Sims3.UI.Dialogs;
using Sims3.UI.Resort;
using Sims3.UI.Hud;
using Sims3.Gameplay.Careers;
using Sims3.Gameplay.EventSystem;

namespace SimStateDudes_SimState
{
	/// <summary>
	/// Description of SimStateDudes_SimState_Core.
	/// </summary>
	public class Core
	{
		//SIM STATE VERSION:
		private static float version = 1.3f;
		
		[Tunable]
        protected static bool kInstantiator = false;
        
        //SETTINGS.
        private static bool allowPowerSurges = true;
        		
        //PERSISTABLE ATTRIBUTES!
        [PersistableStatic]
        public static Dictionary <ulong, bool> powerSurgeDict = new Dictionary<ulong, bool>();
        [PersistableStatic]
		public static Dictionary <ulong, Business_Save> ownedBusinessdDict = new Dictionary<ulong, Business_Save>();
		[PersistableStatic]
		public static Dictionary <SimDescription, bool> thiefDict = new Dictionary<SimDescription, bool>();
		[PersistableStatic]
		public static bool megaStorm = false;
        
		//Loads up Sim State Mod on game load!
		static Core()
        {
        	World.OnWorldLoadFinishedEventHandler += sOnWorldLoadFinished;
        	World.OnWorldQuitEventHandler += OnWorldQuitHandler;
        	//World.OnLotRemovedEventHandler += OnLotRemoved;
        }
		
		private static void OnWorldQuitHandler(object sender, EventArgs e)
		{
			powerSurgeDict.Clear();
			ownedBusinessdDict.Clear();
		}
		
//		private static void OnLotRemoved(object sender, EventArgs e)
//		{
//			if (e.)
//			{
//				
//			}
//		}
        
		//Starts the event handler which runs all Sim State background process checks.
        private static void sOnWorldLoadFinished(object sender, EventArgs e)
        {
        	//Runs the SimState mod.
            AlarmManager.Global.AddAlarm(1f, TimeUnit.Minutes, new AlarmTimerCallback(StartSimState), "Start Sim State", AlarmType.NeverPersisted, null);
            EventManager.EventHandler();
        }
        
        //All modules run from this central start point.
        private static void StartSimState()
        {
        	//NO SIM STATE ON HOLIDAY! :)
        	if (!GameUtils.IsOnVacation())
        	{
        		SimStateWelcome();
        		
        		#region LESSONS MODULE.
        		SimStateDudes_SimState.Lessons lessons = new SimStateDudes_SimState.Lessons();
        		#endregion
        		
        		#region POWER MODULE.
        		SimStateDudes_SimState.PowerSurges powerSurges = new SimStateDudes_SimState.PowerSurges();
        		#endregion
        		
        		#region BUSINESS MODULE.
        		SimStateDudes_SimState.Business business = new SimStateDudes_SimState.Business();
        		#endregion
        	}
        }
        
        //Adds the Sim State Welcome message and the as of yet unused 'Manage Sim State' interaction.
        private static void SimStateWelcome()
        {
        	SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Core:WelcomeToSimState", new object[] {version.ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
        	//Add the Sim State option to the town hall.
        	List<RabbitHole> townHalls = RabbitHole.GetRabbitHolesOfType(RabbitHoleType.CityHall);
        	
        	foreach(RabbitHole townHall in townHalls)
        	{
        		//Uncomment to add back the 'Manage Sim State' interaction... :)
        		//townHall.AddInteraction(SimStateMenu.Singleton);
        	}
        }
        
        private static void SetAllowPowerSurges()
        {
        	allowPowerSurges = !allowPowerSurges;
        }
        
        public class SimStateMenu : ImmediateInteraction<Sim, Sims3.Gameplay.Abstracts.RabbitHole>
        {
        	private sealed class Definition : ImmediateInteractionDefinition<Sim, Sims3.Gameplay.Abstracts.RabbitHole, SimStateMenu>
        	{
        		public override string GetInteractionName(Sim a, Sims3.Gameplay.Abstracts.RabbitHole target, InteractionObjectPair interaction)
        		{
        			return "Manage Sim State";
        		}

        		public override bool Test(Sim a, Sims3.Gameplay.Abstracts.RabbitHole target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
        		{
        			isAutonomous = false;
        			return true;
        		}
        	}

        	public static readonly InteractionDefinition Singleton = new Definition();

        	public override bool Run()
        	{
        		Sim.ActiveActor.ShowTNSIfSelectable("Sim State Menu", Sims3.UI.StyledNotification.NotificationStyle.kGameMessagePositive);
        		return true;
        	}
        }

        //Custom business review dialog based off the code for the resort reviews!
        public class BusinessReviewDialog : ModalDialog
        {
        	public enum ControlID
        	{
        		OkButton = 1,
        		LotThumb = 2,
        		Name = 3,
        		Description = 4,
        		ScrollWindow = 5,
        		ScrollingWindow = 6,
        		RatingHolder = 7,
        		RenameButton = 8,
        		StarsStart = 0x10,
        		StarsEnd = 20,
        		AgeText = 0x20,
        		NameText = 33,
        		Bullet1 = 34,
        		Bullet2 = 35,
        		Bullet3 = 36,
        		Autosizer = 48
        	}

        	public const string kLayoutName = "BusinessReviewDialog";

        	public const int kExportId = 3;

        	public const int kMaxResortNameLength = 30;

        	public List<Layout> mScrollingLayouts;

        	public ScrollWindow mScrollWindow;

        	public Window mScrollingWindow;
        	
        	public static uint mBackgroundMusicHandle;

        	public Text mName;

        	public bool mReturnVal;

        	public static BusinessReviewDialog sDialog;

        	public BusinessReviewDialog(PauseMode pauseMode, ulong lotID)
        		: base("BusinessReviewDialog", 3, true, pauseMode, null, true, UICategory.Dialogs)
        	{
        		Button button = mModalDialogWindow.GetChildByID(1u, recursive: true) as Button;
        		button.Click += OnOkClick;
        		button = mModalDialogWindow.GetChildByID(8u, recursive: true) as  Button;
        		button.Click += OnRenameClick;
        		mName = mModalDialogWindow.GetChildByID(3u, recursive: true) as Text;
        		mName.Caption = SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessName();
        		TextEdit textEdit = mModalDialogWindow.GetChildByID(4u, recursive: true) as TextEdit;
        		textEdit.Caption = Core.ownedBusinessdDict[lotID].GetBusinessDescription();
        		textEdit.CursorIndex = 0u;
        		Window window = mModalDialogWindow.GetChildByID(2u, recursive: true) as Window;
        		ImageDrawable imageDrawable = window.Drawable as ImageDrawable;
        		ResourceKey resourceKeyTest = ResourceKey.CreatePNGKey("business_i_empty_star", 0u);
        		if (imageDrawable != null)
        		{
        			try
        			{
        				//imageDrawable.Image = UIManager.LoadUIImage(resourceKeyTest);
        			}
        			catch(Exception e)
        			{
        				SimStateDudes_Little_Helper.Debug.ShowException(e);
        			}
        			window.Invalidate();
        		}
        		UpdateStars(mModalDialogWindow.GetChildByID(7u, recursive: true), (uint)SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessLevel() * 2, 16u);
        		mScrollWindow = mModalDialogWindow.GetChildByID(5u, recursive: true) as ScrollWindow;
        		mScrollWindow.VerticalScrollBar.ArrowDelta = 75;
        		mScrollingWindow = mModalDialogWindow.GetChildByID(6u, recursive: true) as Window;
        		mScrollingWindow.MouseWheel += ScrollingWindowMouseWheel;
        		mScrollingLayouts = new List<Layout>();
        		float num = 0f;
        		ILocalizationModel localizationModel = Responder.Instance.LocalizationModel;
        		//List<IResortReviewData> reviews = resortData.GetReviews();
        		int count = 1;
        		for (int num2 = count - 1; num2 >= 0; num2--)
        		{
        			//IResortReviewData resortReviewData = reviews[num2];
        			ResourceKey resKey = ResourceKey.CreateUILayoutKey("BusinessReviewEntry", 0u);
        			Layout layout = UIManager.LoadLayoutAndAddToWindow(resKey, mScrollingWindow);
        			if (layout != null)
        			{
        				mScrollingLayouts.Add(layout);
        				Window window2 = layout.GetWindowByExportID(1) as Window;
        				UpdateStars(window2.GetChildByID(7u, recursive: true), (uint)SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessLevel() * 2, 16u);
        				Text text = window2.GetChildByID(33u, recursive: true) as Text;
        				text.Caption = Business.GetBusinessOpenClose(lotID).ToUpper();
        				text = window2.GetChildByID(32u, recursive: true) as Text;
        				text.Caption = "";
        				//List<IResortReviewPoint> reviewPoints = 3;
        				text = window2.GetChildByID(34u, recursive: true) as Text;
        				text.Caption = Localization.LocalizeString("SimStateDudes/SimState/Core:BusinessOverviewData", new object[] {SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessName(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessOpening().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessClosing().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessAccount().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessProfit().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessLevel().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessXP().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetBusinessPoints().ToString(),SimStateDudes_SimState.Core.ownedBusinessdDict[lotID].GetMSLastScore().ToString(), Core.ownedBusinessdDict[lotID].GetBusinessAdvertOnline().ToString(), Core.ownedBusinessdDict[lotID].GetBusinessAdvertTV().ToString()});
        				AutosizeBaseController autosizeBaseController = window2.GetChildByID(48u, recursive: true) as AutosizeBaseController;
        				autosizeBaseController.AutosizeFields();
        				Rect area = window2.Area;
        				float height = area.Height;
        				area.SetPosition(0f, num);
        				area.Height = height;
        				window2.Area = area;
        				num += height;
        				area = mScrollingWindow.Area;
        				area.Height = num;
        				mScrollingWindow.Area = area;
        			}
        		}
        		mScrollWindow.Update();
        		mModalDialogWindow.CenterInParent();
        	}

        	public static bool Show(ulong lotID)
        	{
        		if (ModalDialog.EnableModalDialogs && sDialog == null)
        		{
        			sDialog = new BusinessReviewDialog(PauseMode.PauseSimulator, lotID);
        			sDialog.StartModal();
        			bool result = sDialog.mReturnVal;
        			sDialog = null;
        			return result;
        		}
        		return false;
        	}

        	public static void UpdateStars(WindowBase window, uint rating, uint starStart)
        	{
        		uint num = 0u;
        		while (rating != 0)
        		{
        			Window window2 = window.GetChildByID(starStart + num++, true) as Window;
        			if (rating == 1)
        			{
        				window2.SetImage("business_i_half_star");
        				break;
        			}
        			window2.SetImage("business_i_full_star");
        			rating -= 2;
        		}
        	}

        	public void OnOkClick(WindowBase sender, UIButtonClickEventArgs eventArgs)
        	{
        		base.OnTriggerOk();
        	}

        	public void OnRenameClick(WindowBase sender, UIButtonClickEventArgs eventArgs)
       	    {
        		Simulator.AddObject(new Sims3.UI.OneShotFunctionTask(DoRenameTask));
        	}

        	public void DoRenameTask()
        	{
        		string text = StringInputDialog.Show(null, Localization.LocalizeString("SimStateDudes/SimState/Core:RenameBusiness", new object[0]), "", false, 30);
        		if (!string.IsNullOrEmpty(text))
        		{
        			mReturnVal = true;
        			mName.Caption = text;
        			if (Core.ownedBusinessdDict.ContainsKey(Sim.ActiveActor.LotCurrent.LotId))
        			{
        				Core.ownedBusinessdDict[Sim.ActiveActor.LotCurrent.LotId].SetBusinessName(text);
        			}
        		}
        	}

        	public override bool OnEnd(uint endID)
        	{
        		foreach (Layout mScrollingLayout in mScrollingLayouts)
        		{
        			mScrollingLayout.Shutdown();
        			mScrollingLayout.Dispose();
        		}
        		mScrollingLayouts.Clear();
        		return true;
        	}

        	public void ScrollingWindowMouseWheel(WindowBase sender, UIMouseEventArgs eventArgs)
        	{
        		if (mScrollWindow.VerticalScrollBar.Visible)
        		{
        			int num = -(eventArgs.MouseWheelDelta / 100);
        			if (num == 0)
        			{
        				num = ((eventArgs.MouseWheelDelta >= 0) ? 1 : (-1));
        			}
        			if ((num < 0 && !mScrollWindow.VerticalScrollBar.AtTop()) || (num > 0 && !mScrollWindow.VerticalScrollBar.AtBottom()))
        			{
        				int num2 = num * mScrollWindow.VerticalScrollBar.ArrowDelta;
        				num2 = ((mScrollWindow.VerticalScrollBar.Value + num2 < mScrollWindow.VerticalScrollBar.MinValue) ? (mScrollWindow.VerticalScrollBar.MinValue - mScrollWindow.VerticalScrollBar.Value) : num2);
        				num2 = ((mScrollWindow.VerticalScrollBar.Value + num2 > mScrollWindow.VerticalScrollBar.UpperBoundValue - mScrollWindow.VerticalScrollBar.VisibleRange) ? (mScrollWindow.VerticalScrollBar.UpperBoundValue - mScrollWindow.VerticalScrollBar.VisibleRange - mScrollWindow.VerticalScrollBar.Value) : num2);
        				mScrollingWindow.Position = new Vector2(mScrollingWindow.Position.x, mScrollingWindow.Position.y - (float)num2);
        				mScrollWindow.Update();
        			}
        		}
        	}
        }
        
        public class StyledNotification : Notification
        {
        	public struct Format
        	{
        		public string mText;

        		public ObjectGuid mObject1;

        		public ObjectGuid mObject2;

        		public ThumbnailKey mObject1Key;

        		public ThumbnailKey mObject2Key;

        		public float mTimeout;

        		public string mButtonText;

        		public ButtonPressed mButtonPressed;

        		public string mButton2Text;

        		public ButtonPressed mButton2Pressed;

        		public NotificationStyle mStyle;

        		public bool mCloseable;

        		public bool mCloseOnCallback;

        		public bool mCloseOnCallback2;

        		public Color mColorOverride;

        		public ConnectionType mConnectionType;

        		public NotificationManager.TNSCategory mTNSCategory;

        		public List<BulletPoint> mBulletPoints;

        		public Format(string titleText, NotificationStyle style)
        		{
        			mObject1 = default(ObjectGuid);
        			mObject2 = default(ObjectGuid);
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mButtonText = null;
        			mButtonPressed = null;
        			mText = titleText;
        			mTimeout = kDefaultTimeout;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, ObjectGuid object1, NotificationStyle style)
        		{
        			mObject2 = default(ObjectGuid);
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mButtonText = null;
        			mButtonPressed = null;
        			mText = titleText;
        			mObject1 = object1;
        			mTimeout = kDefaultTimeout;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, ObjectGuid object1, ObjectGuid object2, NotificationStyle style)
        		{
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mButtonText = null;
        			mButtonPressed = null;
        			mText = titleText;
        			mObject1 = object1;
        			mObject2 = object2;
        			mTimeout = kDefaultTimeout;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, string buttonText, NotificationStyle style)
        		{
        			mObject1 = default(ObjectGuid);
        			mObject2 = default(ObjectGuid);
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mButtonPressed = null;
        			mText = titleText;
        			mTimeout = kDefaultTimeout;
        			mButtonText = buttonText;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, ObjectGuid object1, string buttonText, NotificationStyle style)
        		{
        			mObject2 = default(ObjectGuid);
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mButtonPressed = null;
        			mText = titleText;
        			mObject1 = object1;
        			mTimeout = kDefaultTimeout;
        			mButtonText = buttonText;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, ObjectGuid object1, ObjectGuid object2, string buttonText, NotificationStyle style)
        		{
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mButtonPressed = null;
        			mText = titleText;
        			mObject1 = object1;
        			mObject2 = object2;
        			mTimeout = kDefaultTimeout;
        			mButtonText = buttonText;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, string buttonText, ButtonPressed buttonPressed, NotificationStyle style)
        		{
        			mObject1 = default(ObjectGuid);
        			mObject2 = default(ObjectGuid);
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mText = titleText;
        			mTimeout = kDefaultTimeout;
        			mButtonText = buttonText;
        			mButtonPressed = buttonPressed;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, ObjectGuid object1, string buttonText, ButtonPressed buttonPressed, NotificationStyle style)
        		{
        			mObject2 = default(ObjectGuid);
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mText = titleText;
        			mObject1 = object1;
        			mTimeout = kDefaultTimeout;
        			mButtonText = buttonText;
        			mButtonPressed = buttonPressed;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}

        		public Format(string titleText, ObjectGuid object1, ObjectGuid object2, string buttonText, ButtonPressed buttonPressed, NotificationStyle style)
        		{
        			mObject1Key = default(ThumbnailKey);
        			mObject2Key = default(ThumbnailKey);
        			mText = titleText;
        			mObject1 = object1;
        			mObject2 = object2;
        			mTimeout = kDefaultTimeout;
        			mButtonText = buttonText;
        			mButtonPressed = buttonPressed;
        			mStyle = style;
        			mCloseable = true;
        			mCloseOnCallback = false;
        			mCloseOnCallback2 = false;
        			mColorOverride = default(Color);
        			mConnectionType = ConnectionType.kDefault;
        			mButton2Text = null;
        			mButton2Pressed = null;
        			mTNSCategory = NotificationManager.TNSCategory.Unknown;
        			mBulletPoints = null;
        		}
        	}

        	public struct BulletPoint
        	{
        		public string mText;

        		public string mImage;

        		public bool mPlainBullet;

        		public BulletPoint(string text, string image)
        		{
        			mText = text;
        			mImage = image;
        			mPlainBullet = false;
        		}

        		public BulletPoint(string text)
        		{
        			mText = text;
        			mImage = null;
        			mPlainBullet = false;
        		}
        	}

        	public enum NotificationStyle : uint
        	{
        		kSimTalking = 1u,
        		kSystemMessage,
        		kGameMessagePositive,
        		kGameMessageNegative,
        		kDebugAlert,
        		kCustom,
        		kCelebrityUpdate
        	}

        	public enum ConnectionType : uint
        	{
        		kSpeech,
        		kSystem,
        		kDefault
        	}

        	public enum ControlDs : uint
        	{
        		kBodyText = 2u,
        		kButton = 3u,
        		kThumbOneBut = 5u,
        		kThumbOneImage = 6u,
        		kThumbTwoBut = 7u,
        		kThumbTwoImage = 8u,
        		kContainer = 9u,
        		kCustomColorShader = 10u,
        		kLeftButton = 11u,
        		kRightButton = 12u,
        		kBulletsHolder = 13u,
        		kCloseButton = 20u,
        		kNoMaskImage = 21u,
        		kCustomBackground = 0x40u,
        		kBlueBackground = 65u,
        		kRedBackground = 66u,
        		kYellowBackground = 67u,
        		kCelebrityBackground = 68u,
        		kBulletPointImage = 167995136u,
        		kBulletPointText = 167995137u
        	}

        	public delegate void ButtonPressed();

        	private ButtonPressed mPressedCallback;

        	private ButtonPressed mPressed2Callback;

        	private bool mCloseOnCallback;

        	private bool mCloseOnCallback2;

        	public Layout mFGLayout;

        	public ObjectGuid mIDOne;

        	public ObjectGuid mIDTwo;

        	private Button mCallbackButton;

        	private Button mCallbackButton2;

        	public WindowBase mContainer;

        	public WindowBase mColoredBackground;

        	public WindowBase mBulletHolder;

        	public Text mTextArea;

        	public Vector2 mBGOffset;

        	public float mButtonOffset;

        	public Rect mOriginalTextSize;

        	public Format mFormat;

        	public string mOverrideThumbnailPngName;

        	public string mOverrideTargetThumbnailPngName;

        	public ProductVersion mProductVersionThumbnail;

        	public ProductVersion mProductVersionTargetThumbnail;

        	public UIImage mThumbnailOneImage;

        	public bool mThumbOneWasImage;

        	public UIImage mThumbnailTwoImage;

        	public List<Layout> mBulletLayouts;

        	public Rect mOriginalTextArea;

        	public Rect mOriginalBGArea;

        	public Rect mOriginalButtonArea;

        	public static ThumbnailKey kInvalidThumbKey = default(ThumbnailKey);

        	public static float kButtonPadding = 15f;

        	[TunableComment("default timeout for notifications (in seconds)")]
        	[Tunable]
        	public static float kDefaultTimeout = 10f;

        	[Tunable]
        	[TunableComment("Styled Notification: Min Chars Per Second for a reasonable reading speed")]
        	public static float kMinCharPerSecond = 25f;

        	[Tunable]
        	[TunableComment("Styled Notification: Amount of Time you should get per character to Read a TNS Messasge")]
        	public static float kSecondsPerCharToRead = 0.05f;

        	public static StyledNotification Show(Format format)
        	{
        		return Show(format, null);
        	}

        	public static StyledNotification Show(Format format, string overrideThumbnailPngName)
        	{
        		return Show(format, overrideThumbnailPngName, null, ProductVersion.BaseGame, ProductVersion.BaseGame);
        	}

        	public static StyledNotification Show(Format format, string overrideThumbnailPngName, string overrideTargetThumbnailPngName)
        	{
        		return Show(format, overrideThumbnailPngName, overrideTargetThumbnailPngName, ProductVersion.BaseGame, ProductVersion.BaseGame);
        	}

        	public static StyledNotification Show(Format format, string overrideThumbnailPngName, string overrideTargetThumbnailPngName, ProductVersion versionThumbnail, ProductVersion versionTargetThumbnail)
        	{
        		if (Responder.Instance.TutorialModel.IsTutorialRunning())
        		{
        			return null;
        		}
        		NotificationManager instance = NotificationManager.Instance;
        		if (format.mTimeout > 0f && (float)format.mText.Length / kMinCharPerSecond > format.mTimeout)
        		{
        			format.mTimeout = (float)format.mText.Length * kSecondsPerCharToRead;
        		}
        		if (format.mTNSCategory == NotificationManager.TNSCategory.Unknown)
        		{
        			switch (format.mStyle)
        			{
        				case NotificationStyle.kSimTalking:
        					format.mTNSCategory = NotificationManager.TNSCategory.Chatty;
        					break;
        				case NotificationStyle.kCustom:
        					if (format.mConnectionType == ConnectionType.kSpeech)
        					{
        						format.mTNSCategory = NotificationManager.TNSCategory.Chatty;
        					}
        					else
        					{
        						format.mTNSCategory = NotificationManager.TNSCategory.Information;
        					}
        					break;
        				default:
        					format.mTNSCategory = NotificationManager.TNSCategory.Information;
        					break;
        			}
        		}
        		if (instance != null)
        		{
        			StyledNotification styledNotification = new StyledNotification(format, format.mTimeout, overrideThumbnailPngName, overrideTargetThumbnailPngName, versionThumbnail, versionTargetThumbnail);
        			instance.Add(styledNotification, format.mTNSCategory);
        			return styledNotification;
        		}
        		return null;
        	}

        	public StyledNotification(Format format, float timeout, string overrideThumbnailPngName, string overrideTargetThumbnailPngName)
        		: base(timeout)
        	{
        		mFormat = format;
        		mOverrideTargetThumbnailPngName = overrideTargetThumbnailPngName;
        		mOverrideThumbnailPngName = overrideThumbnailPngName;
        		mIDOne = mFormat.mObject1;
        		mIDTwo = mFormat.mObject2;
        		if (mIDOne != ObjectGuid.InvalidObjectGuid)
        		{
        			mThumbnailOneImage = UIUtils.GetUIImageFromThumbnailKey(Responder.Instance.HudModel.GetThumbnailForGameObject(mIDOne, bForceUseSimDescription: true));
        		}
        		else if (mFormat.mObject1Key != kInvalidThumbKey)
        		{
        			ThumbnailKey mObject1Key = mFormat.mObject1Key;
        			switch (UIUtils.GetImageTypeFromThumbnailKey(mObject1Key))
        			{
        				case UIUtils.ImageType.None:
        					mThumbnailOneImage = null;
        					break;
        				case UIUtils.ImageType.Icon:
        					mThumbnailOneImage = UIManager.LoadUIImage(mObject1Key.mDescKey);
        					mThumbOneWasImage = true;
        					break;
        				case UIUtils.ImageType.Thumb:
        					mThumbnailOneImage = UIManager.GetThumbnailImage(mObject1Key);
        					break;
        			}
        		}
        		if (mIDTwo != ObjectGuid.InvalidObjectGuid)
        		{
        			mThumbnailTwoImage = UIUtils.GetUIImageFromThumbnailKey(Responder.Instance.HudModel.GetThumbnailForGameObject(mIDTwo, bForceUseSimDescription: true));
        		}
        		else if (mFormat.mObject2Key != kInvalidThumbKey)
        		{
        			mThumbnailTwoImage = UIUtils.GetUIImageFromThumbnailKey(mFormat.mObject2Key);
        		}
        	}

        	public StyledNotification(Format format, float timeout, string overrideThumbnailPngName, string overrideTargetThumbnailPngName, ProductVersion versionThumbnail, ProductVersion versionTargetThumbnail)
        		: this(format, timeout, overrideThumbnailPngName, overrideTargetThumbnailPngName)
        	{
        		mProductVersionThumbnail = versionThumbnail;
        		mProductVersionTargetThumbnail = versionTargetThumbnail;
        	}

        	public override void Show()
        	{
        		NotificationManager instance = NotificationManager.Instance;
        		if (mFormat.mConnectionType == ConnectionType.kSpeech)
        		{
        			mNotificationWindow = instance.GetBackground(NotificationManager.Backgrounds.SpeechConnector);
        		}
        		else
        		{
        			mNotificationWindow = instance.GetBackground(NotificationManager.Backgrounds.SystemConnector);
        		}
        		switch (mFormat.mStyle)
        		{
        			case NotificationStyle.kSimTalking:
        				if (mFormat.mConnectionType == ConnectionType.kDefault)
        				{
        					mNotificationWindow = instance.GetBackground(NotificationManager.Backgrounds.SpeechConnector);
        				}
        				mColoredBackground = mNotificationWindow.GetChildByID(65u, recursive: true);
        				break;
        			case NotificationStyle.kSystemMessage:
        			case NotificationStyle.kGameMessagePositive:
        			case NotificationStyle.kDebugAlert:
        				if (mFormat.mConnectionType == ConnectionType.kDefault)
        				{
        					mNotificationWindow = instance.GetBackground(NotificationManager.Backgrounds.SystemConnector);
        				}
        				mColoredBackground = mNotificationWindow.GetChildByID(67u, recursive: true);
        				break;
        			case NotificationStyle.kCustom:
        				mColoredBackground = mNotificationWindow.GetChildByID(64u, recursive: true);
        				break;
        			case NotificationStyle.kCelebrityUpdate:
        				mNotificationWindow = instance.GetBackground(NotificationManager.Backgrounds.CelebrityBackground);
        				mColoredBackground = mNotificationWindow.GetChildByID(68u, recursive: true);
        				break;
        			default:
        				if (mFormat.mConnectionType == ConnectionType.kDefault)
        				{
        					mNotificationWindow = instance.GetBackground(NotificationManager.Backgrounds.SystemConnector);
        				}
        				mColoredBackground = mNotificationWindow.GetChildByID(66u, recursive: true);
        				break;
        		}
        		if (mColoredBackground != null)
        		{
        			mColoredBackground.Visible = true;
        		}
        		if (mFormat.mObject2 == default(ObjectGuid) && mFormat.mObject2Key == kInvalidThumbKey && string.IsNullOrEmpty(mOverrideTargetThumbnailPngName))
        		{
        			mContainer = instance.GetForeground(NotificationManager.Foregrounds.OneThumb);
        		}
        		else
        		{
        			mContainer = instance.GetForeground(NotificationManager.Foregrounds.TwoThumb);
        		}
        		if (mNotificationWindow != null)
        		{
        			mPressedCallback = mFormat.mButtonPressed;
        			mPressed2Callback = mFormat.mButton2Pressed;
        			mCloseOnCallback = mFormat.mCloseOnCallback;
        			mCloseOnCallback2 = mFormat.mCloseOnCallback2;
        			mIDOne = mFormat.mObject1;
        			mIDTwo = mFormat.mObject2;
        			ObjectGuid b = default(ObjectGuid);
        			mTextArea = mContainer.GetChildByID(2u, recursive: true) as Text;
        			Button button = mNotificationWindow.GetChildByID(20u, recursive: true) as Button;
        			if (button != null)
        			{
        				button.Click += OnCloseButton;
        				if (!mFormat.mCloseable)
        				{
        					button.Visible = false;
        				}
        			}
        			if (mIDOne != b)
        			{
        				button = mNotificationWindow.GetChildByID(5u, recursive: true) as Button;
        				if (button != null)
        				{
        					button.Click += OnThumb1Button;
        					button.Enabled = true;
        				}
        				Window window = mNotificationWindow.GetChildByID(6u, recursive: true) as Window;
        				if (window != null)
        				{
        					ImageDrawable imageDrawable = window.Drawable as ImageDrawable;
        					if (imageDrawable != null)
        					{
        						imageDrawable.Image = mThumbnailOneImage;
        						window.Invalidate();
        					}
        				}
        			}
        			else
        			{
        				button = mNotificationWindow.GetChildByID(5u, recursive: true) as Button;
        				if (button != null)
        				{
        					button.Enabled = false;
        				}
        				Window window2 = mNotificationWindow.GetChildByID(6u, recursive: true) as Window;
        				if (window2 != null)
        				{
        					ImageDrawable imageDrawable2 = window2.Drawable as ImageDrawable;
        					if (imageDrawable2 != null)
        					{
        						if (mFormat.mObject1Key != kInvalidThumbKey)
        						{
        							if (mThumbOneWasImage)
        							{
        								button.Visible = false;
        								window2 = mNotificationWindow.GetChildByID(21u, recursive: true) as Window;
        								imageDrawable2 = window2.Drawable as ImageDrawable;
        							}
        							imageDrawable2.Image = mThumbnailOneImage;
        						}
        						else
        						{
        							button.Visible = false;
        							window2 = mNotificationWindow.GetChildByID(21u, recursive: true) as Window;
        							imageDrawable2 = window2.Drawable as ImageDrawable;
        							switch (mFormat.mStyle)
        							{
        								case NotificationStyle.kSimTalking:
        								case NotificationStyle.kGameMessagePositive:
        								case NotificationStyle.kGameMessageNegative:
        									{
        										ResourceKey resourceKey4 = ResourceKey.CreatePNGKey("tns_icon_bulb", 0u);
        										if (resourceKey4 != ResourceKey.kInvalidResourceKey)
        										{
        											imageDrawable2.Image = UIManager.LoadUIImage(resourceKey4);
        										}
        										break;
        									}
        								case NotificationStyle.kSystemMessage:
        									{
        										ResourceKey resourceKey2 = ResourceKey.CreatePNGKey("tns_icon_warning", 0u);
        										if (resourceKey2 != ResourceKey.kInvalidResourceKey)
        										{
        											imageDrawable2.Image = UIManager.LoadUIImage(resourceKey2);
        										}
        										break;
        									}
        								case NotificationStyle.kCelebrityUpdate:
        									{
        										ResourceKey resourceKey3 = ResourceKey.CreatePNGKey("tns_icon_celeb", ResourceUtils.ProductVersionToGroupId(ProductVersion.EP3));
        										if (resourceKey3 != ResourceKey.kInvalidResourceKey)
        										{
        											imageDrawable2.Image = UIManager.LoadUIImage(resourceKey3);
        										}
        										break;
        									}
        								default:
        									{
        										ResourceKey resourceKey = ResourceKey.CreatePNGKey("tns_icon_stop", 0u);
        										if (resourceKey != ResourceKey.kInvalidResourceKey)
        										{
        											imageDrawable2.Image = UIManager.LoadUIImage(resourceKey);
        										}
        										break;
        									}
        							}
        						}
        						window2.Invalidate();
        					}
        				}
        			}
        			if (mIDTwo != b)
        			{
        				button = mContainer.GetChildByID(7u, recursive: true) as Button;
        				if (button != null)
        				{
        					button.Click += OnThumb2Button;
        					button.Enabled = true;
        				}
        				Window window3 = mContainer.GetChildByID(8u, recursive: true) as Window;
        				if (window3 != null)
        				{
        					ImageDrawable imageDrawable3 = window3.Drawable as ImageDrawable;
        					if (imageDrawable3 != null)
        					{
        						imageDrawable3.Image = mThumbnailTwoImage;
        						window3.Invalidate();
        					}
        				}
        			}
        			else
        			{
        				button = mContainer.GetChildByID(7u, recursive: true) as Button;
        				if (button != null)
        				{
        					button.Enabled = false;
        				}
        				Window window4 = mContainer.GetChildByID(8u, recursive: true) as Window;
        				if (window4 != null)
        				{
        					ImageDrawable imageDrawable4 = window4.Drawable as ImageDrawable;
        					if (imageDrawable4 != null)
        					{
        						if (mFormat.mObject2Key != kInvalidThumbKey)
        						{
        							imageDrawable4.Image = mThumbnailTwoImage;
        						}
        						window4.Invalidate();
        					}
        				}
        			}
        			mCallbackButton = null;
        			mCallbackButton2 = null;
        			if (mFormat.mButtonText != null && mPressedCallback != null)
        			{
        				if (mFormat.mButton2Text != null && mPressed2Callback != null)
        				{
        					mCallbackButton = mContainer.GetChildByID(11u, recursive: true) as Button;
        					mCallbackButton.Caption = mFormat.mButtonText;
        					mCallbackButton.Click += OnCallbackButton;
        					mOriginalButtonArea = mCallbackButton.Area;
        					mCallbackButton.Visible = true;
        					UIUtils.TooltipEllipsisTextIfNecessary(mCallbackButton);
        					mCallbackButton2 = mContainer.GetChildByID(12u, recursive: true) as Button;
        					mCallbackButton2.Caption = mFormat.mButton2Text;
        					mCallbackButton2.Click += OnCallbackButton2;
        					mCallbackButton2.Visible = true;
        					UIUtils.TooltipEllipsisTextIfNecessary(mCallbackButton2);
        				}
        				else
        				{
        					mCallbackButton = mContainer.GetChildByID(3u, recursive: true) as Button;
        					mCallbackButton.Caption = mFormat.mButtonText;
        					mCallbackButton.Visible = true;
        					mOriginalButtonArea = mCallbackButton.Area;
        					Rect area = mCallbackButton.Area;
        					mCallbackButton.AutoSize();
        					if (mCallbackButton.Area.Width > area.Width)
        					{
        						float num = (float)Math.Round((mCallbackButton.Area.Width - area.Width) / 2f);
        						area.Width = mCallbackButton.Area.Width;
        						area.TopLeft = new Vector2(area.TopLeft.x - num, area.TopLeft.y);
        						area.BottomRight = new Vector2(area.BottomRight.x - num, area.BottomRight.y);
        					}
        					mCallbackButton.Area = area;
        					mCallbackButton.Click += OnCallbackButton;
        				}
        			}
        			WindowBase childByID = mNotificationWindow.GetChildByID(10u, recursive: true);
        			childByID.ShadeColor = mFormat.mColorOverride;
        			mBGOffset = mContainer.Area.BottomRight - mContainer.Parent.ScreenToWindow(mTextArea.Parent.WindowToScreen(mTextArea.Area.BottomRight));
        			mOriginalTextArea = mTextArea.Area;
        			mOriginalBGArea = mNotificationWindow.Area;
        			float height = mTextArea.Area.Height;
        			mTextArea.Caption = "f\nf";
        			mTextArea.AutoSize(vertical: true);
        			float height2 = mTextArea.Area.Height;
        			Rect area2 = mTextArea.Area;
        			area2.Height = height2;
        			mTextArea.Area = area2;
        			if (mTextArea.Area.Height > height)
        			{
        				Vector2 b2 = new Vector2(mContainer.Area.Width, mTextArea.Area.BottomRight.y + mBGOffset.y);
        				mContainer.Area = new Rect(mContainer.Area.TopLeft, mContainer.Area.TopLeft + b2);
        				mNotificationWindow.Area = new Rect(mNotificationWindow.Area.TopLeft, mNotificationWindow.Area.TopLeft + b2);
        			}
        			mOriginalTextSize = mTextArea.Area;
        			mTextArea.Caption = mFormat.mText;
        			mTextArea.AutoSize(vertical: true);
        			if (mTextArea.Area.Height < mOriginalTextSize.Height)
        			{
        				int num2 = (int)(mOriginalTextSize.Height / 2f - mTextArea.Area.Height / 2f);
        				Vector2 b3 = new Vector2(0f, num2);
        				mTextArea.Area = new Rect(mTextArea.Area.TopLeft + b3, mTextArea.Area.BottomRight + b3);
        			}
        			float num3 = 0f;
        			if (mFormat.mBulletPoints != null && mFormat.mBulletPoints.Count > 0)
        			{
        				mBulletHolder = mContainer.GetChildByID(13u, recursive: true);
        				mBulletLayouts = new List<Layout>();
        				ResourceKey resKey = ResourceKey.CreateUILayoutKey("NotificationBulletPoint", 0u);
        				foreach (BulletPoint mBulletPoint in mFormat.mBulletPoints)
        				{
        					Layout layout = UIManager.LoadLayoutAndAddToWindow(resKey, mBulletHolder);
        					if (layout == null)
        					{
        						continue;
        					}
        					mBulletLayouts.Add(layout);
        					Text text = layout.GetWindowByExportID(1) as Text;
        					text.Caption = mBulletPoint.mText;
        					float height3 = text.Area.Height;
        					text.AutoSize(vertical: true);
        					text.Position = new Vector2(0f, num3);
        					num3 += Math.Max(height3, text.Area.Height);
        					Window window5 = mBulletHolder.GetChildByID(167995136u, recursive: true) as Window;
        					if (mBulletPoint.mPlainBullet)
        					{
        						window5.Visible = false;
        						Text text2 = mBulletHolder.GetChildByID(167995137u, recursive: true) as Text;
        						text2.Visible = true;
        						text2.TextStyle = text.TextStyle;
        						text2.TextColor = text.TextColor;
        					}
        					else
        					{
        						if (string.IsNullOrEmpty(mBulletPoint.mImage))
        						{
        							continue;
        						}
        						ImageDrawable imageDrawable5 = window5.Drawable as ImageDrawable;
        						if (imageDrawable5 != null)
        						{
        							ResourceKey resourceKey5 = ResourceKey.CreatePNGKey(mBulletPoint.mImage, 0u);
        							if (resourceKey5 != ResourceKey.kInvalidResourceKey)
        							{
        								imageDrawable5.Image = UIManager.LoadUIImage(resourceKey5);
        								window5.Invalidate();
        							}
        						}
        					}
        				}
        			}
        			if (mTextArea.Area.Height > mOriginalTextSize.Height || mCallbackButton != null || num3 != 0f)
        			{
        				Vector2 b4 = new Vector2(mContainer.Area.Width, mTextArea.Area.BottomRight.y + num3);
        				if (mCallbackButton != null)
        				{
        					mButtonOffset = 0f - mCallbackButton.Area.TopLeft.y + kButtonPadding;
        					b4.y += mButtonOffset;
        				}
        				else
        				{
        					b4.y += mBGOffset.y;
        				}
        				mNotificationWindow.Area = new Rect(mContainer.Area.TopLeft, mContainer.Area.TopLeft + b4);
        				mContainer.Area = mNotificationWindow.Area;
        			}
        			if (!string.IsNullOrEmpty(mOverrideThumbnailPngName))
        			{
        				Window window6 = mNotificationWindow.GetChildByID(21u, recursive: true) as Window;
        				if (window6 != null)
        				{
        					window6.SetImage(mOverrideThumbnailPngName, mProductVersionThumbnail);
        				}
        				window6 = mNotificationWindow.GetChildByID(6u, recursive: true) as Window;
        				if (window6 != null)
        				{
        					window6.Visible = false;
        				}
        			}
        			if (!string.IsNullOrEmpty(mOverrideTargetThumbnailPngName))
        			{
        				Window window7 = mContainer.GetChildByID(8u, recursive: true) as Window;
        				if (window7 != null)
        				{
        					window7.SetImage(mOverrideTargetThumbnailPngName, mProductVersionTargetThumbnail);
        				}
        			}
        		}
        		mContainer.Visible = true;
        		base.Show();
        	}

        	public void OnCloseButton(WindowBase sender, UIButtonClickEventArgs eventArgs)
        	{
        		CloseNow();
        		eventArgs.Handled = true;
        	}

        	public void OnThumb1Button(WindowBase sender, UIButtonClickEventArgs eventArgs)
        	{
        		FocusOnNotificationObject(mIDOne);
        		eventArgs.Handled = true;
        	}

        	public void OnThumb2Button(WindowBase sender, UIButtonClickEventArgs eventArgs)
        	{
        		FocusOnNotificationObject(mIDTwo);
        		eventArgs.Handled = true;
        	}

        	public void FocusOnNotificationObject(ObjectGuid objGuid)
        	{
        		if (Responder.Instance.HudModel.GetInventoryContainingObject(objGuid) != null)
        		{
        			Responder.Instance.HudModel.OpenInventoryContainingObject(objGuid);
        		}
        		else if (!Responder.Instance.HudModel.CheckAndMoveCameraToSim(objGuid))
        		{
        			ICameraModel cameraModel = Responder.Instance.CameraModel;
        			Vector3 objectWorldPosition = cameraModel.GetObjectWorldPosition(objGuid);
        			if (objectWorldPosition != Vector3.OutOfWorld)
        			{
        				cameraModel.FocusOnGivenPosition(objectWorldPosition, 1f);
        			}
        		}
        	}

        	public void OnCallbackButton(WindowBase sender, UIButtonClickEventArgs eventArgs)
        	{
        		mPressedCallback();
        		if (mCloseOnCallback)
        		{
        			CloseNow();
        		}
        		eventArgs.Handled = true;
        	}

        	public void OnCallbackButton2(WindowBase sender, UIButtonClickEventArgs eventArgs)
        	{
        		mPressed2Callback();
        		if (mCloseOnCallback2)
        		{
        			CloseNow();
        		}
        		eventArgs.Handled = true;
        	}

        	public override void Hide()
        	{
        		base.Hide();
        		if (!(mNotificationWindow != null))
        		{
        			return;
        		}
        		if (mCallbackButton != null)
        		{
        			mCallbackButton.Caption = "";
        			mCallbackButton.TooltipText = "";
        			mCallbackButton.Area = mOriginalButtonArea;
        			mCallbackButton.Click -= OnCallbackButton;
        			mCallbackButton.Visible = false;
        			mCallbackButton = null;
        		}
        		if (mCallbackButton2 != null)
        		{
        			mCallbackButton2.Caption = "";
        			mCallbackButton2.TooltipText = "";
        			mCallbackButton2.Click -= OnCallbackButton2;
        			mCallbackButton2.Visible = false;
        			mCallbackButton2 = null;
        		}
        		Button button = mNotificationWindow.GetChildByID(20u, recursive: true) as Button;
        		if (button != null)
        		{
        			button.Click -= OnCloseButton;
        			if (!button.Visible)
        			{
        				button.Visible = true;
        			}
        		}
        		button = mNotificationWindow.GetChildByID(5u, recursive: true) as Button;
        		if (button != null)
        		{
        			button.Click -= OnThumb1Button;
        			button.Visible = true;
        		}
        		button = mContainer.GetChildByID(7u, recursive: true) as Button;
        		if (button != null)
        		{
        			button.Click -= OnThumb2Button;
        			button.Visible = true;
        		}
        		Window window = mNotificationWindow.GetChildByID(6u, recursive: true) as Window;
        		if (window != null)
        		{
        			window.SetImage(null);
        			window.Visible = true;
        		}
        		window = mNotificationWindow.GetChildByID(21u, recursive: true) as Window;
        		if (window != null)
        		{
        			window.SetImage(null);
        			window.Visible = true;
        		}
        		window = mContainer.GetChildByID(8u, recursive: true) as Window;
        		if (window != null)
        		{
        			window.SetImage(null);
        			window.Visible = true;
        		}
        		if (mColoredBackground != null)
        		{
        			mColoredBackground.Visible = false;
        		}
        		if (mBulletLayouts != null)
        		{
        			foreach (Layout mBulletLayout in mBulletLayouts)
        			{
        				mBulletLayout.Shutdown();
        				mBulletLayout.Dispose();
        			}
        			mBulletLayouts.Clear();
        			mBulletLayouts = null;
        		}
        		mBulletHolder = null;
        		mColoredBackground = null;
        		mContainer.Visible = false;
        		mNotificationWindow.Area = mOriginalBGArea;
        		mContainer.Area = mOriginalBGArea;
        		mTextArea.Area = mOriginalTextArea;
        		mNotificationWindow = null;
        		mContainer = null;
        	}

        	public override void Clean()
        	{
        		if (mCallbackButton != null)
        		{
        			mCallbackButton.Click -= OnCallbackButton;
        		}
        		if (mCallbackButton2 != null)
        		{
        			mCallbackButton2.Click -= OnCallbackButton2;
        		}
        		Button button = mNotificationWindow.GetChildByID(20u, recursive: true) as Button;
        		if (button != null)
        		{
        			button.Click -= OnCloseButton;
        		}
        		button = mNotificationWindow.GetChildByID(5u, recursive: true) as Button;
        		if (button != null)
        		{
        			button.Click -= OnThumb1Button;
        		}
        		button = mNotificationWindow.GetChildByID(7u, recursive: true) as Button;
        		if (button != null)
        		{
        			button.Click -= OnThumb2Button;
        		}
        	}

        	public override void Dispose(bool fromDtor)
        	{
        		if (mFGLayout != null)
        		{
        			mCallbackButton = null;
        			mCallbackButton2 = null;
        			mContainer = null;
        			mTextArea = null;
        			mFGLayout.Shutdown();
        			mFGLayout = null;
        		}
        		if (!fromDtor)
        		{
        			GC.SuppressFinalize(this);
        		}
        		base.Dispose(fromDtor);
        	}
        }

	}
}
