﻿//SimStateDudes - Sim State - Events Module
using System;
using System.Collections.Generic;
using Sims3.SimIFace;
using Sims3.Gameplay.EventSystem;
using Sims3.Gameplay.Objects;
using Sims3.Gameplay.Objects.Electronics;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.Utilities;
using Sims3.Gameplay.Core;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Situations;
using Sims3.Gameplay.CAS;
using Sims3.UI;
using Sims3.SimIFace.CAS;

namespace SimStateDudes_SimState
{
	/// <summary>
	/// Description of Class.
	/// </summary>
	public class EventManager
	{
		
		public static void EventHandler()
		{
			//ON NEW OBJECT PURCHASE EVENT.
			EventTracker.AddListener(EventTypeId.kBoughtObject, OnNewObject);
			EventTracker.AddListener(EventTypeId.kVisitLot, OnLotVisited);
			EventTracker.AddListener(EventTypeId.kSimEnterSpecificLot, OnLotEntered);
			
			StartAlarms();
		}
		
		//Sim State Alarm goes off every 1 Sim Hour (Minute), opening or closing businesses, pushing Sims to the lot etc. The Tick Alarm does a 20 Sim Minute check.
		public static void StartAlarms()
		{
			AlarmManager.Global.AddAlarmDay(0f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 0",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(1f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 1",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(2f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 2",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(3f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 3",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(4f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 4",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(5f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 5",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(6f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 6",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(7f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 7",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(8f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 8",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(9f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 9",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(10f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 10",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(11f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 11",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(12f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 12",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(13f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 13",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(14f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 14",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(15f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 15",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(16f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 16",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(17f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 17",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(18f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 18",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(19f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 19",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(20f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 20",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(21f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 21",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(22f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 22",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmDay(23f,DaysOfTheWeek.All,OnSimStateAlarmCheck,"Sim State Alarm 23",AlarmType.AlwaysPersisted,null);
			AlarmManager.Global.AddAlarmRepeating(20f,TimeUnit.Minutes,OnTickAlarmCheck,10f,TimeUnit.Minutes,"Sim State Tick Alarm",AlarmType.AlwaysPersisted,null);
		}
		
		//Sim State Time Check.
		public static void OnSimStateAlarmCheck()
		{
			try
			{
				foreach (KeyValuePair <ulong, Business_Save> business in Core.ownedBusinessdDict)
				{
					if (!GameUtils.IsOnVacation())
					{
						//Give closing soon message for businesses.
						if (SimClock.Hours24 == (business.Value.GetBusinessClosing() - 1) && business.Value.GetBusinessOpenClose() == true)
						{
							if (business.Value.business15MinutesTillClose == false && business.Key == Sim.ActiveActor.LotCurrent.LotId)
							{
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:ClosingSoon", new object[1] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
								business.Value.business15MinutesTillClose = true;
							}
						}
						
						//Close businesses outside opening/closing times.
						if (SimClock.Hours24 == business.Value.GetBusinessClosing() && business.Value.GetBusinessOpenClose() == true && business.Value.GetBusinessAccount() >= 1)
						{
							//Business now closed dialog if on the lot.
							if (Sim.ActiveActor.LotCurrent.LotId == business.Key)
							{
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:BusinessNowClosed", new object[] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							}
							business.Value.SetBusinessOpenClose();
							
							//Remove all employee interactions.
							Employees.RemoveEmployeeInteractions(business.Key, null);
							
							//Turn off all lights at closing time.
							LightGameObject[] objects = Sims3.Gameplay.Queries.GetObjects<LightGameObject>(LotManager.GetLot(business.Key));
							foreach (LightGameObject obj in objects)
							{
								//Switch off the lights at the end of the business day.
								obj.SwitchLight(false,true);
							}
							
							//Send sims home.
							Sim[] sims = Sims3.Gameplay.Queries.GetObjects<Sim>(LotManager.GetLot(business.Key));
							foreach (Sim sim in sims)
							{
								if (!sim.IsInActiveHousehold)
								{
									//Employees change back to everyday outfit.
									if (Employees.CheckIfEmployedHere(business.Key,sim))
									{
										sim.PushSwitchToOutfitInteraction(Sim.ClothesChangeReason.GoingOffLot,OutfitCategories.Everyday);
									}
									if (!sim.Household.IsServiceNpcHousehold && !sim.Household.IsPetHousehold && !sim.Household.IsServobotHousehold)
									{
										sim.InteractionQueue.CancelAllInteractions();
										//Sim sent home...
										Sim.MakeSimGoHome(sim, false, new InteractionPriority(InteractionPriorityLevel.High));
									}
								}
							}
						}
						else if (SimClock.Hours24 == business.Value.GetBusinessOpening() && business.Value.GetBusinessAccount() >= 1)
						{
							//BUSINESS OPENING CHECKS.
							//Say business now opening if on the same lot!
							if (Sim.ActiveActor.LotCurrent.LotId == business.Key)
							{
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:BusinessNowOpen", new object[] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							}
							
							//CALL IN EMPLOYEES IN THE MORNING!
							foreach(KeyValuePair<SimDescription,Business_Employees> employee in business.Value.GetCurrentEmployees())
							{
								//Reset sent home status for all employees.
								if(employee.Value.GetEmployeeSentHome())
								{
									employee.Value.ResetSentHome();
								}
								Employees.CallInEmployees(business.Key,SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId),true);
							}
							
							if (business.Value.GetBusinessOpenClose() == false)
							{
								business.Value.SetBusinessOpenClose();
							}
							business.Value.business15MinutesTillClose = false;
							
							//DECREMENT ANY ADVERTISING & SHOW MESSAGE WHEN THE CAMPAIGN HAS ENDED!
							if (business.Value.GetBusinessAdvertOnline() > 0)
							{
								business.Value.DecrementAdvertOnline();
								if (business.Value.GetBusinessAdvertOnline() == 0)
								{
									SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:OnlineAdvertEnded", new object[] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
								}
								else if (business.Value.GetBusinessAdvertOnline() == 1)
								{
									SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:OnlineAdvertNearlyEnded", new object[] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
								}
							}
							if (business.Value.GetBusinessAdvertTV() > 0)
							{
								business.Value.DecrementAdvertTV();
								if (business.Value.GetBusinessAdvertTV() == 0)
								{
									SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:TVAdvertEnded", new object[] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
								}
								else if (business.Value.GetBusinessAdvertTV() == 1)
								{
									SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:TVAdvertNearlyEnded", new object[] {business.Value.GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
								}
							}
						}
						
						if (business.Value.GetBusinessAccount() <= 0 && business.Value.GetBusinessOpenClose() == true)
						{
							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Events:NoMoney", new object[] {business.Value.GetBusinessName(), business.Value.GetBusinessAccount().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							business.Value.SetBusinessOpenClose();
						}
					}
					
					//Check if business is open and how many people on the lot & if require more!
					Business.SimOnLotManager();
					
					//Pay all employees!
					Employees.PayEmployeeCheck();
				
				}
				
			}
			catch(Exception e)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(e);
			}
		}
		
		public static void OnTickAlarmCheck()
		{
			//Manage any employees on the lot and push them to do certain tasks!
			try
			{
				if (!GameUtils.IsOnVacation())
				{
					//Brings employees to the lot etc
					Employees.ManagePushEmployees();
				}
			}
			catch(Exception e)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(e);
			}
		}
		
		public static void OnThiefCaughtCheck()
		{
			if (!GameUtils.IsOnVacation())
			{
				//Find the thief, remove the interaction, clear dictionary.
				foreach(KeyValuePair<SimDescription,bool> sim in Core.thiefDict)
				{
					Sim newSim = SimDescription.GetCreatedSim(sim.Key.SimDescriptionId);
					newSim.RemoveInteractionByType(StopThief.Singleton);
					Core.thiefDict.Remove(sim.Key);
				}
			}
		}
		
//		protected static ListenerAction OnChangeHousehold(Event e)
//		{
//
//		}
		
		//Adds Sim State interactions to new objects. (Computer Interactions/Set For Sale etc)
		protected static ListenerAction OnNewObject(Event e)
		{
			//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Event",SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
			try
			{
				if (!GameUtils.IsOnVacation())
				{
					Computer computer = e.TargetObject as Computer;
					if (computer != null)
					{
						//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Computer Event",SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						computer.AddInteraction(StartBusiness.Singleton);
						if (Core.ownedBusinessdDict.ContainsKey(computer.LotCurrent.LotId) != false)
						{
							//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Add Deposit/Withdraw Interaction",SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							computer.AddInteraction(DepositFunds.Singleton);
							computer.AddInteraction(WithdrawFunds.Singleton);
							computer.AddInteraction(ShutdownBusiness.Singleton);
							computer.AddInteraction(AdvertiseBusiness.Singleton);
							
						}
					}
					
					GameObject newObject = e.TargetObject as GameObject;
					if (newObject != null && SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(newObject.LotCurrent.LotId) && SimStateDudes_SimState.Core.ownedBusinessdDict[newObject.LotCurrent.LotId].GetEnableSetForSale())
					{
						newObject.AddInteraction(SimStateDudes_SimState.SetForSale.Singleton);
					}
				}
			}
			catch(Exception ex)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(ex);
			}
			return ListenerAction.Keep;
		}
		
		//Auto invites in Sims who visit business lots.
		protected static ListenerAction OnLotVisited(Event e)
		{
			try
			{
				if (!GameUtils.IsOnVacation())
				{
					//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Visit Lot Event",SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
					Sim sim = e.Actor as Sim;
					//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Sim Name: "+sim.GetLocalizedName(),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
					if (sim != null && Core.ownedBusinessdDict.ContainsKey(sim.LotCurrent.LotId) && sim.LotCurrent.LotId == Sim.ActiveActor.LotCurrent.LotId)
					{
						//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Found Business",SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						VisitSituation.OnInvitedIn(sim);
						if (!sim.IsSelectable)
						{
							GoInsideLotAndSocialize goInsideLotAndSocialize = GoInsideLotAndSocialize.Singleton.CreateInstance(Sim.ActiveActor, sim, new InteractionPriority(InteractionPriorityLevel.High), isAutonomous: false, cancellableByPlayer: true) as GoInsideLotAndSocialize;
							sim.InteractionQueue.Add(goInsideLotAndSocialize);
						}
					}
				}
			}
			catch(Exception ex)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(ex);
			}
			return ListenerAction.Keep;
		}
		
		protected static ListenerAction OnLotEntered(Event e)
		{
			try
			{
				if (!GameUtils.IsOnVacation())
				{
					//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Visit Lot Event",SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
					Sim sim = e.Actor as Sim;
					//SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format("Sim Name: "+sim.GetLocalizedName(),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
					if (sim != null && Core.ownedBusinessdDict.ContainsKey(sim.LotCurrent.LotId) && sim.LotCurrent.LotId == Sim.ActiveActor.LotCurrent.LotId)
					{
						if (Core.ownedBusinessdDict[sim.LotCurrent.LotId].GetCurrentEmployees().ContainsKey(sim.SimDescription))
						{
							Employees.AddEmployeeInteractions(sim.LotCurrent.LotId);
							Core.ownedBusinessdDict[sim.LotCurrent.LotId].GetCurrentEmployees()[sim.SimDescription].IncrementShiftsWorked();
						}
					}
				}
			}
			catch(Exception ex)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(ex);
			}
			return ListenerAction.Keep;
		}
	}
}
