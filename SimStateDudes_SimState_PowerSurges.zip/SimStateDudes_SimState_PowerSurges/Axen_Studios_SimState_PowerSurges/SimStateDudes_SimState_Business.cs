﻿//SimStateDudes - Sim State - Business Module
using System;
using System.Collections.Generic;
using Sims3.SimIFace;
using Sims3.SimIFace.BuildBuy;
using Sims3.Gameplay.Objects.Electronics;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.Interfaces;
using Sims3.Gameplay.Autonomy;
using Sims3.UI;
using Sims3.Gameplay.EventSystem;
using Sims3.Gameplay.RealEstate;
using Sims3.Gameplay.CAS;
using Sims3.Gameplay.Core;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.ObjectComponents;
using Sims3.Gameplay.Objects;
using Sims3.Gameplay.Objects.Alchemy;
using Sims3.Gameplay.Objects.CookingObjects;
using Sims3.Gameplay.Objects.Decorations;
using Sims3.Gameplay.Objects.Fishing;
using Sims3.Gameplay.Objects.FoodObjects;
using Sims3.Gameplay.Objects.Gardening;
using Sims3.Gameplay.Objects.HobbiesSkills;
using Sims3.Gameplay.Objects.HobbiesSkills.Inventing;
using Sims3.Gameplay.Objects.Insect;
using Sims3.Gameplay.Objects.RabbitHoles;
using Sims3.Gameplay.Objects.Register;
using Sims3.Gameplay.Objects.Spawners;
using Sims3.Gameplay.Objects.Toys;
using Sims3.Gameplay.ActorSystems;
using Sims3.Store.Objects;
using Sims3.Gameplay.Utilities;
using Sims3.Gameplay.Services;
using Sims3.Gameplay.Controllers;
using Sims3.Gameplay.Situations;

namespace SimStateDudes_SimState
{
	/// <summary>
	/// Description of SimStateDudes_SimState_Business.
	/// </summary>
	public class Business
	{
		
		public const int businessStartCost = 1000;
		
		public Business()
		{
			//Add all custom interactions to the game.
			AddBaseInteractions();
		}
		
		private static void AddBaseInteractions()
        {
			bool alreadyAdded = false;
        	//COMPUTER MANAGE BASE INTERACTIONS.
        	Computer[] computers = Sims3.Gameplay.Queries.GetObjects<Computer>();
        	foreach (Computer computer in computers)
        	{
        		alreadyAdded = false;
        		//Check if the object already has the set for sale interaction.
        		foreach (InteractionObjectPair interaction in computer.Interactions)
				{
        			if (interaction.InteractionDefinition.GetType() == StartBusiness.Singleton.GetType())
					{
						alreadyAdded = true;
						break;
        			}
				}
        		
        		//Only add the interaction to computers on lots owned by the active household.
        		if (alreadyAdded == false)
        		{
        			computer.AddInteraction(StartBusiness.Singleton);
        		}
        		
        		if (Core.ownedBusinessdDict.ContainsKey(computer.LotCurrent.LotId))
        		{
        			computer.AddInteraction(DepositFunds.Singleton);
        			computer.AddInteraction(WithdrawFunds.Singleton);
        			computer.AddInteraction(ShutdownBusiness.Singleton);
        			computer.AddInteraction(AdvertiseBusiness.Singleton);
        		}
        	}
        	
        	if (Core.ownedBusinessdDict.Count != 0)
        	{
        		//ADD SET FOR SALE INTERACTION TO ALL OBJECTS IN EACH BUSINESS IF SET FOR SALE ENABLED.
        		foreach (KeyValuePair <ulong, Business_Save> business in Core.ownedBusinessdDict)
        		{
        			if (business.Value.GetEnableSetForSale())
        			{
        				try
        				{
        					bool alreadyAddedSetForSale = false;
        					GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(LotManager.GetLot(business.Key));
        					foreach (GameObject obj in objects)
        					{
        						alreadyAdded = false;
        						//Check if the object already has the set for sale interaction.
        						foreach (InteractionObjectPair interaction in obj.Interactions)
        						{
        							if (interaction.InteractionDefinition.GetType() == SetForSale.Singleton.GetType())
        							{
        								alreadyAddedSetForSale = true;
        								break;
        							}
        						}
        						if (alreadyAddedSetForSale == false && Core.ownedBusinessdDict[LotManager.GetLot(business.Key).LotId].GetObjectsForSale().ContainsKey(obj.ObjectId) == false)
        						{
        							obj.AddInteraction(SetForSale.Singleton);
        						}
        					}
        					
        				}
        				catch(Exception e)
        				{
        					SimStateDudes_Little_Helper.Debug.ShowException(e);
        				}
        			}
        			
        			//Add employee interactions for employees on the lot!
        			Employees.AddEmployeeInteractions(business.Key);
        			
        			//Check if any objects are set for sale on this lot.
        			if (business.Value.GetObjectsForSale().Count > 0)
        			{
        				//Loop through all objects added for sale on the lot.
        				foreach (KeyValuePair <ObjectGuid, ObjectForSale> objectForSale in business.Value.GetObjectsForSale())
        				{
        					if (objectForSale.Value.GetObjectSold() == false)
        					{
        						GameObject.GetObject(objectForSale.Value.GetObjectID()).RemoveAllInteractions();
        						GameObject.GetObject(objectForSale.Value.GetObjectID()).AddInteraction(BuyObject.Singleton);
        						GameObject.GetObject(objectForSale.Value.GetObjectID()).AddInteraction(ModifyCost.Singleton);
        						GameObject.GetObject(objectForSale.Value.GetObjectID()).AddInteraction(RemoveFromSale.Singleton);
        					}
        					else
        					{
        						GameObject.GetObject(objectForSale.Value.GetObjectID()).RemoveAllInteractions();
        						GameObject.GetObject(objectForSale.Value.GetObjectID()).AddInteraction(RestockObject.Singleton);
        					}
        				}
        			}
        		}
        	}
        }
		
		//Objects to allow in the sim inventory on purchase!
		public static bool CheckSimInventory(GameObject obj)
		{
			if (obj.GetType() == typeof(Book))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookGeneral))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookSkill))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookRecipe))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookToddler))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookFish))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookAlchemyRecipe))
			{
				return true;
			}
			else if (obj.GetType() == typeof(BookComic))
			{
				return true;
			}
			else if (obj.GetType() == typeof(CraftedToyBoxToy))
			{
				return true;
			}
			else if (obj.GetType() == typeof(CraftedCow))
			{
				return true;
			}
			else if (obj.GetType() == typeof(CraftedDog))
			{
				return true;
			}
			else if (obj.GetType() == typeof(CraftedRobot))
			{
				return true;
			}
			else if (obj.GetType() == typeof(CraftedToy4))
			{
				return true;
			}
			else if (obj.GetType() == typeof(DrinkingLlama))
			{
				return true;
			}
			else if (obj.GetType() == typeof(WindUpToy))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Carousel))
			{
				return true;
			}
			else if (obj.GetType() == typeof(StaticCoil))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Levitation))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Sims3.Gameplay.Objects.HobbiesSkills.Inventing.FishTank))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Harvester))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Miner))
			{
				return true;
			}
			else if (obj.GetType() == typeof(MoonGlobe))
			{
				return true;
			}
			else if (obj.GetType() == typeof(NewtonsCradle))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Sims3.Gameplay.Objects.HobbiesSkills.Inventing.Robot))
			{
				return true;
			}
			else if (obj.GetType() == typeof(TimeMachine))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Potion))
			{
				return true;
			}
			else if (obj.GetType() == typeof(NectarBottle))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Ingredient))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Fish))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Rock))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Gem))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Widget))
			{
				return true;
			}
			else if (obj.GetType() == typeof(SheetMusic))
			{
				return true;
			}
			else if (obj.GetType() == typeof(PlateServing))
			{
				return true;
			}
			else if (obj.GetType() == typeof(NormalTerrarium))
			{
				return true;
			}
			else if (obj.GetType() == typeof(AlchemyPotion))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Metal))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Invention))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Photograph))
			{
				return true;
			}
			else if (obj.GetType() == typeof(Sculpture))
			{
				return true;
			}
			else if (obj.GetType() == typeof(ServingContainer))
			{
				return true;
			}
			else if (obj.GetType() == typeof(ServingContainerGroup))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		public static void CalculateMarkupAndSetForSale(GameObject obj)
		{
			ulong lotID = obj.LotCurrent.LotId;
			int price = 0;
			//Make sure the item is on a lot with a valid business.
			if (Core.ownedBusinessdDict.ContainsKey(obj.LotCurrent.LotId))
			{
				//Check the type of object and apply the markup.
				if (obj.GetType() == typeof(Book))
				{
					price = obj.mIntPrice + 10;
				}
				else if (obj.mIntPrice <= 0)
				{
					price = 100;
				}
				else
				{
					price = obj.mIntPrice + (obj.mIntPrice / 100 * 5);
				}
				
				if (Core.ownedBusinessdDict[lotID].GetObjectsForSale().ContainsKey(obj.ObjectId))
				{
					Core.ownedBusinessdDict[lotID].GetObjectsForSale()[obj.ObjectId].SetObjectCost(price);
				}
				else
				{
					Core.ownedBusinessdDict[lotID].AddObjectForSale(obj.ObjectId,price);
				}
			}
		}

		public static void ShutdownBusinessProcedure(ulong lotID)
		{
			try
			{
				//Remove employee interactions.
				foreach(KeyValuePair<SimDescription,Business_Employees> employee in Core.ownedBusinessdDict[lotID].GetCurrentEmployees())
				{
					Employees.RemoveEmployeeInteractions(lotID,employee.Value.GetSimDescription());
					//Lay off each employee.
					Employees.ShowEmployeeFiredMessage(lotID,SimDescription.GetCreatedSim(employee.Key.SimDescriptionId));
					Employees.GiveSeverancePay(lotID,SimDescription.GetCreatedSim(employee.Key.SimDescriptionId));
				}
				
				//Find all objects that are set for sale and reset them.
				GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(LotManager.GetLot(lotID));
				foreach (GameObject obj in objects)
				{
					if (Core.ownedBusinessdDict[lotID].GetObjectsForSale().ContainsKey(obj.ObjectId))
					{
						obj.RemoveAllInteractions();
						obj.SetColorTint(100f,100f,100f,0f);
						obj.SetOpacity(1f,0f);
						IGameObject gameObject = Sims3.Gameplay.GlobalFunctions.CreateObjectOutOfWorld(obj.GetResourceKey());
						//Get the interactions of the cloned object and place them on the original.
						foreach(InteractionObjectPair interaction in gameObject.Interactions)
						{
							if (interaction.CheckIfInteractionValid())
							{
								//Add all the valid interactions!
								obj.AddInteraction(interaction.InteractionDefinition);
							}
						}
					}
				}
				
				//Send all non household sims home.
				Sim[] sims = Sims3.Gameplay.Queries.GetObjects<Sim>(LotManager.GetLot(lotID));
				foreach(Sim sim in sims)
				{
					if (!sim.IsInActiveHousehold)
					{
						Sim.MakeSimGoHome(sim,true);
					}
				}
				
				Core.ownedBusinessdDict.Remove(lotID);
				Business.AddBaseInteractions();
			}
			catch(Exception e)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(e);
			}
		}
				
		public static int GetBuyChance(int price)
		{
			if (price <= 250)
			{
				return 3;
			}
			else if (price <= 500)
			{
				return 8;
			}
			else if (price <= 1000)
			{
				return 15;
			}
			else if (price <= 2000)
			{
				return 25;
			}
			else if (price <= 5000)
			{
				return 40;
			}
			else if (price <= 7500)
			{
				return 75;
			}
			else if (price <= 10000)
			{
				return 150;
			}
			else if (price > 10000)
			{
				return 200;
			}
			else
			{
				return 3;
			}
		}
		
		public static int GetRankMarkupMax(ulong lotID)
		{
			switch (Core.ownedBusinessdDict[lotID].GetBusinessLevel())
			{
				case 2:
					return 10;
				case 3:
					return 15;
				case 4:
					return 20;
				case 5:
					return 25;
				default:
					return 5;
			}
		}
		
		//Get maximum customers called to the store within an hour.
		public static int GetMaxCustomers(int rank)
		{
			switch (rank)
			{
				case 2:
					return 5;
				case 3:
					return 7;
				case 4:
					return 9;
				case 5:
					return 11;
				default:
					return 4;
			}
		}
		
		//Get maximum number of employees allowed per rank!
		public static int GetMaxEmployees(int rank)
		{
			switch(rank)
			{
				case 2:
					return 4;
				case 3:
					return 6;
				case 4:
					return 8;
				case 5:
					return 10;
				default:
					return 2;
			}
		}
		
		//Provides the Open/Close string for an active business.
		public static string GetBusinessOpenClose(ulong lotID)
		{
			if (Core.ownedBusinessdDict.ContainsKey(lotID))
			{
				if (Core.ownedBusinessdDict[lotID].GetBusinessOpenClose())
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Business/GetOpenClose:Open", new object[0]);
				}
				else
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Business/GetOpenClose:Close", new object[0]);
				}
			}
			return Localization.LocalizeString("SimStateDudes/SimState/Business/GetOpenClose:Null", new object[0]);
		}
		
		//Criteria for if  the customer was happy with their purchase and gain a satisfaction point.
		public static void CheckCustomerSatisfaction(Sim actor, int basePrice, int price)
		{
			//FRUGAL SIMS.
			if (actor.TraitManager.HasElement(TraitNames.Frugal))
			{
				//Frugal sims will not be satisfied if the markup is above 5.
				if (price > basePrice + (basePrice / 100 * 5))
				{
					//Will not be happy with inflated prices unless rank level 5.
					if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessLevel() < 5)
					{
						Core.ownedBusinessdDict[actor.LotCurrent.LotId].RemoveBusinessPoints(1);
					}
					else
					{
						if (!actor.MoodManager.IsInNegativeMood)
						{
							Core.ownedBusinessdDict[actor.LotCurrent.LotId].AddBusinessPoints(1);
						}
					}
				}
				else if (price < basePrice)
				{
					Core.ownedBusinessdDict[actor.LotCurrent.LotId].AddBusinessPoints(1);
				}
			}
			
			//GOOD SIMS.
			if (actor.TraitManager.HasElement(TraitNames.Good))
			{
				//Good Sims always give satisfaction points even in a bad mood!
				Core.ownedBusinessdDict[actor.LotCurrent.LotId].AddBusinessPoints(1);
			}
			
			//ALL OTHER SIMS.
			if (!actor.TraitManager.HasElement(TraitNames.Good) && !actor.TraitManager.HasElement(TraitNames.Frugal))
			{
				//Default behaviour for most sims. Will allow markup up to 10% for under level 5 and 20% for level 5. Anything above they will not be satisfied but will buy it.
				if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessLevel() < 5)
				{
					if (price > basePrice + (basePrice / 100 * 10))
					{
						
					}
					else
					{
						if (!actor.MoodManager.IsInNegativeMood)
						{
							Core.ownedBusinessdDict[actor.LotCurrent.LotId].AddBusinessPoints(1);
						}
					}
				}
				else
				{
					if (price > basePrice + (basePrice / 100 * 20))
					{
						
					}
					else
					{
						if (!actor.MoodManager.IsInNegativeMood)
						{
							Core.ownedBusinessdDict[actor.LotCurrent.LotId].AddBusinessPoints(1);
						}
					}
				}
			}
			
		}
		
		private static string GiveMSBonus(Sim actor, int score)
		{
			if (score == 100)
			{
				actor.ModifyFunds(score * 10);
				return Localization.LocalizeString("SimStateDudes/SimState/Business/GiveMSBonus:1", new object[1] {(score * 10).ToString()});
			}
			else if (score >= 90)
			{
				actor.ModifyFunds(score * 5);
				return Localization.LocalizeString("SimStateDudes/SimState/Business/GiveMSBonus:2", new object[1] {(score * 5).ToString()});
			}
			else if (score >= 75)
			{
				actor.ModifyFunds(score * 3);
				return Localization.LocalizeString("SimStateDudes/SimState/Business/GiveMSBonus:3", new object[1] {(score * 3).ToString()});
			}
			else if (score < 75)
			{
				actor.ModifyFunds(-score * 3);
				return Localization.LocalizeString("SimStateDudes/SimState/Business/GiveMSBonus:4", new object[1] {(score * 3).ToString()});
			}
			else
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business/GiveMSBonus:null", new object[0]);
			}
		}
		
		//Mystery shopper should visit the shop randomly from time to time and rate their experience.
		public static bool CheckIfMysteryShopper(Sim actor)
		{
			if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessLevel() >= 2 && Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessPoints() >= 10)
			{
				int mysteryChance = RandomUtil.GetInt(1,25);
				if (mysteryChance == 1)
				{
					int mysteryShopperScore = 100;
					if (!actor.MoodManager.IsInNegativeMood)
					{
						int restockCount = 0;
						int highPriceCount = 0;
						foreach (var val in Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetObjectsForSale().Values)
						{
							if (val.GetObjectSold() == true)
							{
								restockCount++;
							}
							
							int maxObjectCost = GameObject.GetObject(val.GetObjectID()).Cost + (GameObject.GetObject(val.GetObjectID()).Cost / 100)* GetRankMarkupMax(actor.LotCurrent.LotId);
							
							if (val.GetObjectCost() > maxObjectCost)
							{
								highPriceCount++;
							}
						}
						
						if (restockCount <= 25)
						{
							mysteryShopperScore -= restockCount;							
						}
						else
						{
							mysteryShopperScore -= 25;
						}
						
						if (highPriceCount <= 10)
						{
							mysteryShopperScore -= highPriceCount;							
						}
						else
						{
							mysteryShopperScore -= 10;
						}
						
						if (restockCount >= 5)
						{
							if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessLevel() >= 3)
							{
								mysteryShopperScore -= (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessLevel() * 2);
							}
						}
						
						if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessPoints() >= 100)
						{
							if (highPriceCount >= 10)
							{
								mysteryShopperScore -= 5;
							}
						}
						
						//Chance of closing the store if the mystery shopper score is low 3 times in a row.
						if (mysteryShopperScore <= 60)
						{
							Core.ownedBusinessdDict[actor.LotCurrent.LotId].IncrementMSFailRate();
						}
						
						if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetMSFailRate() > 3)
						{
							//CLOSE THE STORE/PAY A FINE?
						}
						
						Core.ownedBusinessdDict[actor.LotCurrent.LotId].SetMSLastScore(mysteryShopperScore);
						
						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Business:CheckIfMysteryShopper", new object[4] {actor.GetLocalizedName(),Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetBusinessName(),mysteryShopperScore, GiveMSBonus(actor, mysteryShopperScore)}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						return true;
					}
				}
			}
			return false;
		}
		
		public static bool CheckIfThief(ulong lotID, Sim actor)
		{
			int upperThiefChance = 3;
			if (Core.ownedBusinessdDict.ContainsKey(lotID))
			{
				//Reduce rate of theft if the player has a security system.
				if (Core.ownedBusinessdDict[lotID].businessSecuritySystem == true)
				{
					upperThiefChance = 10;
				}
			}
			
			if (actor.TraitManager.HasElement(TraitNames.Kleptomaniac) || actor.TraitManager.HasElement(TraitNames.Evil) || RandomUtil.GetInt(1,25) == 1)
			{
				int thiefChance = RandomUtil.GetInt(1,upperThiefChance);
				if (thiefChance == 1)
				{
					if (Core.ownedBusinessdDict.ContainsKey(lotID))
					{
						if (Core.ownedBusinessdDict[lotID].businessSecuritySystem == true)
						{
							CaughtSituation.Create(actor.LotCurrent,actor, TNSNames.BustedPerformingStreetArt);
							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/StopThief:CaughtThief", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						}
						else
						{
							actor.AddInteraction(StopThief.Singleton);
						}
					}
					
					return true;
				}
			}
			
			return false;
		}
		
		public static void BusinessLevelUp(ulong LotId, string BusinessName, int BusinessRank)
		{
			if (Employees.CheckIfEmployeeHasRole(Sim.ActiveActor.LotCurrent.LotId,Sim.ActiveActor, Employees.EmployeeRoles.Manager))
			{
				//All sims start clapping!
				Sim[] sims = Sims3.Gameplay.Queries.GetObjects<Sim>(Sim.ActiveActor.LotCurrent);
				foreach (Sim sim in sims)
				{
					sim.InteractionQueue.CancelAllInteractions();
					sim.RouteToObjectRadius(Sim.ActiveActor,2f);
					sim.PlaySoloAnimation("a_react_cheer_x", false);
				}
				
				if (BusinessRank <= 4)
				{
					Audio.StartSound("sting_career_positive");
					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Business:BusinessLevelUp", new object[2] {BusinessName, BusinessRank.ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
				}
				
				else if (BusinessRank == 5)
				{
					Audio.StartSound("sting_career_max");
					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Business:BusinessMaxLevel", new object[] {BusinessName}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
					Core.ownedBusinessdDict[LotId].AddToBusinessAccount(10000);
				}
			}
		}
        
        //Add the Set for Sale interaction to all specified objects.
		public static void AddSetForSaleInteraction(Lot lot)
		{
			try
			{
				bool alreadyAdded = false;
				GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(lot);
				foreach (GameObject obj in objects)
				{
					alreadyAdded = false;
					//Check if the object already has the set for sale interaction.
					foreach (InteractionObjectPair interaction in obj.Interactions)
					{
						if (interaction.InteractionDefinition.GetType() == SetForSale.Singleton.GetType())
						{
							alreadyAdded = true;
							break;
						}
						
						if (interaction.InteractionDefinition.GetType() == BuyObject.Singleton.GetType())
						{
							alreadyAdded = true;
							break;
						}
						
						if (interaction.InteractionDefinition.GetType() == RestockObject.Singleton.GetType())
						{
							alreadyAdded = true;
							break;
						}
					}
					if (alreadyAdded == false)
					{
						obj.AddInteraction(SetForSale.Singleton);
					}
				}
			}
			catch(Exception e)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(e);
			}
        	
		}
		
		//Remove the Set for Sale interaction to all specified objects.
		public static void RemoveSetForSaleInteraction(Lot lot)
		{
			GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(lot);
        	foreach (GameObject obj in objects)
        	{
        		obj.RemoveInteractionByType(SetForSale.Singleton);
        	}
		}
		
		//Add the remove from sale interaction.
		public static void RemoveFromSaleInteraction(GameObject obj)
		{
        	obj.AddInteraction(RemoveFromSale.Singleton);	
		}
		
		//Deal with the set for sale code.
		public static void SetForSaleInteraction(GameObject obj)
		{
			//Add the option to buy the object.
			obj.AddInteraction(BuyObject.Singleton);
		}
		
		//Invites sims if there aren't enough on the lot currently.
		public static void SimOnLotManager()
		{
			try
			{
				//If the active actor is on a lot that contains a business.
				if (Core.ownedBusinessdDict.ContainsKey(Sim.ActiveActor.LotCurrent.LotId) && Core.ownedBusinessdDict[Sim.ActiveActor.LotCurrent.LotId].GetBusinessOpenClose() == true)
				{
					Lot lotCurrent = Sim.ActiveActor.LotCurrent;
					int maxAmountOfSimsOnLot = Core.ownedBusinessdDict[lotCurrent.LotId].GetCurrentEmployees().Count + GetMaxCustomers(Core.ownedBusinessdDict[lotCurrent.LotId].GetBusinessLevel()) + Sim.ActiveActor.Household.NumMembers;
					Sim[] currentSims = Sims3.Gameplay.Queries.GetObjects<Sim>(lotCurrent);
					if (currentSims.Length >= maxAmountOfSimsOnLot)
					{
						//Nothing!
					}
					else
					{
						int simCount = 1;
						Sim[] checkSims = Sims3.Gameplay.Queries.GetObjects<Sim>();
						//Get random sims up to the amount of customers required...
						int maxGroupSize = RandomUtil.GetInt(0,(maxAmountOfSimsOnLot - currentSims.Length));
						
						//Increased customer amounts if using advertising! -- Online
						if (Core.ownedBusinessdDict[Sim.ActiveActor.LotCurrent.LotId].GetBusinessAdvertOnline() > 0)
						{
							int addSims = RandomUtil.GetInt(1,2);
							maxGroupSize += addSims;
						}
						
						//Televised advertising!
						if (Core.ownedBusinessdDict[Sim.ActiveActor.LotCurrent.LotId].GetBusinessAdvertTV() > 0)
						{
							int addSims = RandomUtil.GetInt(1,5);
							maxGroupSize += addSims;
						}
						
						Sim[] sims = new Sim[maxGroupSize];
						if (sims.Length != 0)
						{
							for (int i = 0;i < sims.Length;i++)
							{
								sims[i] = RandomUtil.GetRandomObjectFromList(checkSims);
							}
							
							foreach(Sim sim in sims)
							{
								if (sim.SimDescription.ChildOrAbove && !sim.SimDescription.IsServicePerson && sim.CareerManager.CareerHoursTillWork > 2 && !sim.IsAtWork)
								{
									//Invite to the lot.
									sim.InteractionQueue.CancelAllInteractions();
									InteractionInstance interactionInstance = VisitLot.Singleton.CreateInstance(lotCurrent, sim, new InteractionPriority(InteractionPriorityLevel.High), isAutonomous: false, cancellableByPlayer: true);
									sim.InteractionQueue.AddNext(interactionInstance);
									simCount++;
								}
							}
						}
					}
				}
			}
			catch(Exception e)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(e);
			}
		}
		
	}
	
	[Persistable]
	public class Business_Save
	{
		private ulong businessLotID;
		private string businessName;
		private string businessDescription;
		private Dictionary<ObjectGuid, ObjectForSale> objectsForSale = new Dictionary<ObjectGuid, ObjectForSale>();
		private Dictionary<SimDescription, Business_Employees> businessEmployees = new Dictionary<SimDescription, Business_Employees>();
		private int businessOpenTime = 9;
		private int businessCloseTime = 17;
		private bool businessOpen = false;
		private bool setForSale = false;
		private int businessAccount = 0;
		private int businessProfit;
		private int businessLevel = 1;
		private int businessXP = 0;
		private int businessPoints = 0;
		private int businessMSLastScore;
		private int businessMSFailRate = 0;
		
		//Business advertising.
		private int businessAdvertOnline = 0;
		private int businessAdvertTV = 0;
		
		//Last 15 minutes message check.
		public bool business15MinutesTillClose = false;
		
		//Business Rewards!
		public bool businessReward1k = false;
		public bool businessReward5k = false;
		public bool businessSecuritySystem = false;
		public bool businessSuperRestock = false;
		
		public Business_Save()
		{
			
		}
		
		public Business_Save(ulong lotID, string bName, string bDescription)
		{
			businessLotID = lotID;
			businessName = bName;
			businessDescription = bDescription;
		}
		
		public string GetBusinessName()
		{
			return businessName; 
		}
		
		public string GetBusinessDescription()
		{
			return businessDescription;
		}
		
		public int GetBusinessOpening()
		{
			return businessOpenTime;
		}
		
		public int GetBusinessClosing()
		{
			return businessCloseTime;
		}
		
		public bool GetBusinessOpenClose()
		{
			if (businessOpen)
			{
				return true;
			}
			return false;
		}
		
		public int GetBusinessAccount()
		{
			return businessAccount;
		}
		
		public int GetBusinessProfit()
		{
			return businessProfit;
		}
		
		public int GetBusinessLevel()
		{
			return businessLevel;
		}
		
		public int GetBusinessXP()
		{
			return businessXP;
		}
		
		public int GetBusinessPoints()
		{
			return businessPoints;
		}
		
		public bool GetEnableSetForSale()
		{
			return setForSale;
		}
		
		public int GetMSLastScore()
		{
			return businessMSLastScore;
		}
		
		public int GetMSFailRate()
		{
			return businessMSFailRate;
		}
		
		public int GetBusinessAdvertOnline()
		{
			return businessAdvertOnline;
		}
		
		public int GetBusinessAdvertTV()
		{
			return businessAdvertTV;
		}
		
		public Dictionary<ObjectGuid, ObjectForSale> GetObjectsForSale()
		{
			return objectsForSale;
		}
		
		public Dictionary<SimDescription, Business_Employees> GetCurrentEmployees()
		{
			return businessEmployees;
		}
		
		public void StartAdvertOnline()
		{
			businessAdvertOnline = 7;
		}
		
		public void StartAdvertTV()
		{
			businessAdvertTV = 7;
		}
		
		public void AddToBusinessAccount(int amount)
		{
			businessAccount += amount;			
		}
		
		public void AddBusinessProfit(int profit)
		{
			businessProfit += profit;
		}
		
		public void AddObjectForSale(ObjectGuid id, int cost)
		{
			ObjectForSale newObject = new ObjectForSale(id, cost);
			objectsForSale.Add(id, newObject);
		}
		
		public void AddNewEmployee(SimDescription simDescription)
		{
			Business_Employees newEmployee = new Business_Employees(simDescription);
			businessEmployees.Add(simDescription, newEmployee);
		}
		
		public void AddBusinessXP(int XP)
		{
			businessXP += XP;
			CheckXPLevelUp();
		}
		
		public void AddBusinessPoints(int points)
		{
			businessPoints += points;
		}
		
		public void SetBusinessName(string name)
		{
			businessName = name;
		}
		
		public void SetBusinessDescription(string description)
		{
			businessDescription = description;
		}
		
		public void SetBusinessOpening(int opening)
		{
			businessOpenTime = opening;
		}
		
		public void SetBusinessClosing(int closing)
		{
			businessCloseTime = closing;
		}
		
		public void SetBusinessOpenClose()
		{
			businessOpen = !businessOpen;
		}
		
		public void SetEnableSetForSale()
		{
			setForSale = !setForSale;
		}
		
		public void SetMSLastScore(int lastScore)
		{
			businessMSLastScore = lastScore;
		}
		
		public void IncrementMSFailRate()
		{
			businessMSFailRate++;
		}
		
		private void CheckXPLevelUp()
		{
			if (businessXP >= 500 && businessLevel < 2)
			{
				businessLevel++;
				Business.BusinessLevelUp(businessLotID,businessName,businessLevel);
			}
			else if (businessXP >= 5000 && businessLevel < 3)
			{
				businessLevel++;
				Business.BusinessLevelUp(businessLotID,businessName,businessLevel);
			}
			else if (businessXP >= 10000 && businessLevel < 4)
			{
				businessLevel++;
				Business.BusinessLevelUp(businessLotID,businessName,businessLevel);
			}
			else if (businessXP >= 25000 && businessLevel < 5)
			{
				businessLevel++;
				Business.BusinessLevelUp(businessLotID,businessName,businessLevel);
			}
		}
		
		public void RemoveEmployee(SimDescription simDescription)
		{
			if (businessEmployees.ContainsKey(simDescription))
			{
				businessEmployees.Remove(simDescription);
			}
		}
		
		public void RemoveFromBusinessAccount(int amount)
		{
			businessAccount -= amount;
		}
		
		public void RemoveBusinessPoints(int points)
		{
			businessPoints -= points;
		}
		
		public void DecrementAdvertOnline()
		{
			if (businessAdvertOnline > 0)
			{
				businessAdvertOnline--;
			}
		}
		
		public void DecrementAdvertTV()
		{
			if (businessAdvertTV > 0)
			{
				businessAdvertTV--;
			}
		}
	}
	
	[Persistable]
	public class SalesRecord
	{
		private string simName;
		private string objectSold;
		private int objectCost;
		
		public SalesRecord()
		{
			
		}
		
		public SalesRecord(string name, string obj, int objCost)
		{
			simName = name;
			objectSold = obj;
			objectCost = objCost;
		}
	}
	
	[Persistable]
	public class ObjectForSale
	{
		private ObjectGuid objectID;
		private int objectCost;
		private bool objectSold = false;
		private bool objectBeingRestocked = false;
		
		public ObjectForSale()
		{
			
		}
		
		public ObjectForSale(ObjectGuid id, int cost)
		{
			objectID = id;
			objectCost = cost;
		}
		
		public ObjectGuid GetObjectID()
		{
			return objectID;
		}
		
		public int GetObjectCost()
		{
			return objectCost;
		}
		
		public bool GetObjectSold()
		{
			return objectSold;
		}
		
		public bool GetObjectBeingRestocked()
		{
			return objectBeingRestocked;
		}
		
		public void SetObjectCost(int newCost)
		{
			objectCost = newCost;
		}
		
		public void SetObjectSold(bool result)
		{
			objectSold = result;
		}
		
		public void SetObjectBeingRestocked()
		{
			objectBeingRestocked = !objectBeingRestocked;
		}
	}
	
	//EMPLOYEE OBJECT.
	[Persistable]
	public class Business_Employees
	{
		private const int employeeMaxLevel = 5;
		
		private SimDescription simDescription;
		private Employees.EmployeeRoles employeeRole;
		private int employeeWagePerHour = Employees.employeeMinimumWage;
		private int employeeShiftsWorked = 0;
		private bool sentHome = false;
		
		public Business_Employees()
		{
			
		}
		
		public Business_Employees(SimDescription desc)
		{
			simDescription = desc;
		}
		
		public SimDescription GetSimDescription()
		{
			return simDescription;
		}
		
		public Employees.EmployeeRoles GetEmployeeRole()
		{
			return employeeRole;
		}
		
		public bool GetEmployeeSentHome()
		{
			return sentHome;
		}
		
		public int GetEmployeeWagePerHour()
		{
			return employeeWagePerHour;
		}
		
		public int GetEmployeeShiftsWorked()
		{
			return employeeShiftsWorked;
		}
		
		public void ResetSentHome()
		{
			sentHome = false;
		}
		
		public void SendEmployeeHome()
		{
			sentHome = true;
		}
		
		public void SetEmployeeRole(Employees.EmployeeRoles role)
		{
			employeeRole = role;
		}
		
		public void SetEmployeeWagePerHour(int wage)
		{
			employeeWagePerHour = wage;
		}
		
		public void IncrementShiftsWorked()
		{
			employeeShiftsWorked++;
		}
	}
	
	//MANAGE BUSINESS!
	public class StartBusiness : ImmediateInteraction<Sim, Sims3.Gameplay.Objects.Electronics.Computer>
	{
		private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, StartBusiness>
		{
			public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:StartABusiness", new object[0]);
			}
			
			public override string[] GetPath(bool isFemale)
			{
				return new string[1] {Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:RealEstate...", new object[0])};
			}

			public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				isAutonomous = false;
				return true;
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			//Check if there is already a business on the lot, if not check if the user has access to buildbuy mode on the lot and allow them to create a new business.
			if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
			{
				SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:AlreadyABusiness", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
			}
			else
			{
				if (base.Actor.FamilyFunds >= Business.businessStartCost)
				{
					if (TwoButtonDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:ThanksForRequestForLicense", new object[0]), Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:PayBusinessLicenseCost", new object[] {Business.businessStartCost.ToString()}), Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:CloseString", new object[0])))
					{
						string businessName = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:NewBusinessName", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:EnterABusinessName", new object[0]),"",false);
						string businessDescription = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:NewBusinessDescription", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:EnterABusinessDescription", new object[0]),"",false);
						if (businessName == "" || businessDescription == "")
						{
							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:BusinessNameNotEmpty", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						}
						else
						{
							Business_Save newBusiness = new Business_Save(base.Target.LotCurrent.LotId,businessName,businessDescription);
							//Add the business to the business dictionary.
							Core.ownedBusinessdDict.Add(base.Target.LotCurrent.LotId,newBusiness);
							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:CongratulationsOnStartingANewBusiness", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							Audio.StartSound("sting_career_positive");
							//Remove Active Sim from Career, make retired.
							//Add as employee with manager level.
							if (base.Actor.Occupation != null)
            				{
            					base.Actor.Occupation.RetireNoConfirmation();
            				}
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddNewEmployee(base.Actor.SimDescription);
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[base.Actor.SimDescription].SetEmployeeRole(Employees.EmployeeRoles.Manager);
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[base.Actor.SimDescription].SetEmployeeWagePerHour(Employees.EmployeeExpectedWage(Employees.EmployeeRoles.Manager));
							Employees.AddEmployeeInteractions(base.Target.LotCurrent.LotId);
							
							base.Actor.ModifyFunds(-Business.businessStartCost);
							Computer[] computers = Sims3.Gameplay.Queries.GetObjects<Computer>(base.Target.LotCurrent);
							foreach (Computer computer in computers)
							{
								computer.AddInteraction(DepositFunds.Singleton);
								computer.AddInteraction(WithdrawFunds.Singleton);
								computer.AddInteraction(ShutdownBusiness.Singleton);
								computer.AddInteraction(AdvertiseBusiness.Singleton);
							}
						}
					}
				}
				else
				{
					SimpleMessageDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:StartingNewBusiness", new object[0]), Localization.LocalizeString("SimStateDudes/SimState/StartBusiness:SorryMinimumNeeded", new object[] {Business.businessStartCost.ToString()}));
				}
				
			}
			return true;
		}
	}
	
	//DEPOSIT BUSINESS FUNDS INTERACTION.
	public sealed class DepositFunds : ImmediateInteraction<Sim, Sims3.Gameplay.Objects.Electronics.Computer>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, DepositFunds>
            {
                public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
                {
                    return Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:DepositFunds", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:Manage Business...", new object[0])};
				}
                
                public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			string depositFunds = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:DepositFundsTitle", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:DepositFundsSubTitle", new object[0]),"",true);
						int result;
						int.TryParse(depositFunds, out result);
						if (result > 0)
						{
							if (base.Actor.FamilyFunds >= result)
							{
								base.Actor.Household.ModifyFamilyFunds(-result);
								Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(result);
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:DepositSuccess", new object[] {result.ToString(),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							}
							else
							{
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:NotEnoughMoney", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							}
						}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
	
	//ADVERTISE BUSINESS!
	public sealed class AdvertiseBusiness : ImmediateInteraction<Sim, Sims3.Gameplay.Objects.Electronics.Computer>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, AdvertiseBusiness>
            {
                public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
                {
                    return Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:Interaction", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:Manage Business...", new object[0])};
				}
                
                public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			Sims3.UI.ThreeButtonDialog.ButtonPressed buttonPressed = ThreeButtonDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:ChooseAdvertOption", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:ChooseInternet", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:ChooseTV", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:Cancel", new object[0]));
            			
            			if (Sims3.UI.ThreeButtonDialog.ButtonPressed.FirstButton == buttonPressed)
            			{
            				//Online Advert - A few extra customers, random cash grants from online sponsers.
            				if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() >= 1000)
            				{
            					if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAdvertOnline() == 0)
            					{
            						Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].StartAdvertOnline();
            						Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveFromBusinessAccount(1000);
            						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectOnlineAdvert", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            					}
            					else
            					{
            						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectOnlineAdvertAlreadyRunning", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAdvertOnline().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            					}
            				}
            				else
            				{
            					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectOnlineAdvertNoMoney", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            				}
            			}
            			else if (Sims3.UI.ThreeButtonDialog.ButtonPressed.SecondButton == buttonPressed)
            			{
            				//TV Advert - Lots of customers, a boost of XP.
            				if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() >= 5000)
            				{
            					if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAdvertTV() == 0)
            					{
            						Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].StartAdvertTV();
            						Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveFromBusinessAccount(5000);
            						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectTVAdvert", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            					}
            					else
            					{
            						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectTVAdvertAlreadyRunning", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAdvertTV().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            					}
            				}
            				else
            				{
            					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectTVAdvertNoMoney", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            				}
            			}
            			else if (Sims3.UI.ThreeButtonDialog.ButtonPressed.ThirdButton == buttonPressed)
            			{
            				//No advertising selected message.
            				SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/AdvertiseBusiness:SelectNoAdvertising", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            			}
            			
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
	
	//CLOSE DOWN BUSINESS INTERACTION.
	public sealed class ShutdownBusiness : ImmediateInteraction<Sim, Sims3.Gameplay.Objects.Electronics.Computer>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, ShutdownBusiness>
            {
                public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
                {
                    return Localization.LocalizeString("SimStateDudes/SimState/ShutDownBusiness:InteractionName", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:Manage Business...", new object[0])};
				}
                
                public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		bool closeBusiness;
            		closeBusiness = TwoButtonDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/ShutDownBusiness:DialogTitle", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/ShutDownBusiness:TrueClose", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/ShutDownBusiness:FalseKeep", new object[0]));
            			
            		if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId) && closeBusiness == true)
            		{
            			SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/ShutDownBusiness:ClosedDown", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            			Business.ShutdownBusinessProcedure(base.Target.LotCurrent.LotId);
            		}
            	}
            	return true;
            }
        }
	
	//WITHDRAW FROM BUSINESS ACCOUNT!
	public sealed class WithdrawFunds : ImmediateInteraction<Sim, Sims3.Gameplay.Objects.Electronics.Computer>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, WithdrawFunds>
            {
                public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
                {
                    return Localization.LocalizeString("SimStateDudes/SimState/WithdrawFunds:WithdrawFunds", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/DepositFunds:Manage Business...", new object[0])};
				}
                
                public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			string depositFunds = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/WithdrawFunds:WithdrawFundsTitle", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/WithdrawFunds:WithdrawFundsSubTitle", new object[0]),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount().ToString(),true);
						int result;
						int.TryParse(depositFunds, out result);
						if (result > 0)
						{
							if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() >= result)
							{
								base.Actor.Household.ModifyFamilyFunds(result);
								Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveFromBusinessAccount(result);
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/WithdrawFunds:WithdrawSuccess", new object[] {result.ToString(),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(),Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							}
							else
							{
								SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/WithdrawFunds:NotEnoughMoney", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
							}
						}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
	
	//SET FOR SALE INTERACTION.
	public class SetForSale : ImmediateInteraction<Sim, Sims3.Gameplay.Abstracts.GameObject>
	{
		public sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, SetForSale>
		{
			
			public InteractionVisualTypes GetVisualType = InteractionVisualTypes.Opportunity;
			
			public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business:SetForSale", new object[0]);
			}

			public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				isAutonomous = false;
				if (Employees.CheckIfEmployeeHasRole(target.LotCurrent.LotId, a, Employees.EmployeeRoles.Manager))
				{
					return true;
				}
				else
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
					return false;
				}
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			base.Target.RemoveAllInteractions();
			//ADD THE BUY INTERACTION.
			Business.SetForSaleInteraction(base.Target);
			//ADD THE REMOVE INTERACTION.
			Business.RemoveFromSaleInteraction(base.Target);
			//ADD THE MODIFY COST INTERACTION.
			base.Target.AddInteraction(ModifyCost.Singleton);
			//REMOVE SET FOR SALE OPTION.
			base.Target.RemoveInteractionByType(SetForSale.Singleton);
			//TINT THE OBJECT WHITE!
			if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
			{
				base.Target.SetColorTint(0f,100f,0f,0f);
			}
			//ADD THE OBJECT TO THE OBJECTS LIST IF NOT ALREADY ADDED.
			if (!Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().ContainsKey(base.Target.ObjectId))
			{
				try
				{
					Business.CalculateMarkupAndSetForSale(base.Target);
				}
				catch(Exception e)
				{
					SimStateDudes_Little_Helper.Debug.ShowException(e);
				}
			}
			return true;
		}
	}
	
	//REMOVE FROM SALE.
	public class RemoveFromSale : ImmediateInteraction<Sim, Sims3.Gameplay.Abstracts.GameObject>
	{
		private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, RemoveFromSale>
		{
			public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business:RemoveFromSale", new object[0]);
			}

			public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				isAutonomous = false;
				if (Employees.CheckIfEmployeeHasRole(a.LotCurrent.LotId,a, Employees.EmployeeRoles.Manager))
				{
					return true;
				}
				else
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
					return false;
				}
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			try
			{
				//Clear interactions.
				base.Target.RemoveAllInteractions();
				//Get the interactions from the original object.
				IGameObject gameObject = Sims3.Gameplay.GlobalFunctions.CreateObjectOutOfWorld(base.Target.GetResourceKey());
				
				//Get the interactions of the cloned object and place them on the original.
				foreach(InteractionObjectPair interaction in gameObject.Interactions)
				{
					if (interaction.CheckIfInteractionValid())
					{
						//Add all the valid interactions!
						base.Target.AddInteraction(interaction.InteractionDefinition);
					}
				}
				
				//CHANGE COLOR BACK TO NORMAL.
				if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
				{
					base.Target.SetColorTint(100f,100f,0f,0f);
				}
				
				//REMOVE FROM OBJECT DICTIONARY.
				Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().Remove(base.Target.ObjectId);
				
				//Readd the set for sale interaction!
				if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
				{
					base.Target.AddInteraction(SetForSale.Singleton);
				}
			}
			catch(Exception e)
			{
				SimStateDudes_Little_Helper.Debug.ShowException(e);
			}
			return true;
		}
	}
	
	//RESTOCK OBJECT.
	public class RestockObject : Interaction<Sim, Sims3.Gameplay.Abstracts.GameObject>
	{
		private sealed class Definition : InteractionDefinition<Sim, IGameObject, RestockObject>
		{
			public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business:RestockObject", new object[1] {target.GetLocalizedName()});
			}

			public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				if (Employees.CheckIfEmployeeHasRole(a.LotCurrent.LotId,a, Employees.EmployeeRoles.Manager))
				{
					return true;
				}
				else if (Employees.CheckIfEmployeeCanRestock(a))
				{
					return true;
				}
				else
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YouDontWorkHere", new object[0]));
					return false;
				}
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			if (base.Actor.RouteToObjectRadialRangeAndCheckInUse(base.Target, 0.5f, 2f) && base.Target.IsSafeToDelete())
			{			
				
				//Restock animation!				
				base.StandardEntry();
                base.BeginCommodityUpdates();
                base.EnterStateMachine("UniversityWelcomeKit", "EnterUniversity", "x");
                base.AnimateSim("LoopTest");
                bool flag = base.DoTimedLoop(2f, ExitReason.Default);
                base.AnimateSim("ExitAptituteTest");
                base.EndCommodityUpdates(flag);
                base.StandardExit();
				
                try
                {
                	//Reset price.
					BuildBuyProduct product = base.Target.Product;	
					base.Target.mIntPrice = ((!(product == null)) ? ((int)product.Price) : 0);
					if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() >= base.Target.mIntPrice)
					{
						base.Target.RemoveAllInteractions();
                	
						//ADD THE BUY INTERACTION.
						Business.SetForSaleInteraction(base.Target);
						//ADD THE REMOVE INTERACTION.
						Business.RemoveFromSaleInteraction(base.Target);
						//ADD THE MODIFY COST INTERACTION.
						base.Target.AddInteraction(ModifyCost.Singleton);
						
						//CHANGE COLOR BACK TO GREEN.
						if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
						{
							base.Target.SetColorTint(0f,100f,0f,0f);
						}
						
						base.Target.SetOpacity(1f,0f);
						
						if (base.Target.mIntPrice > 0)
						{
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveFromBusinessAccount(base.Target.mIntPrice);
						}
						
						//Set as unsold again.
						Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[base.Target.ObjectId].SetObjectSold(false);
						
						//Set 5% markup.
						Business.CalculateMarkupAndSetForSale(base.Target);
						Repoman.FireTeleportEffect(base.Target);
					}
					else
					{
						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Restock:NotEnoughMoney", new object[] {base.Target.GetLocalizedName(), base.Target.mIntPrice.ToString(), Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().Remove(base.Target.ObjectId);
						base.Target.Destroy();
					}
				}
				catch(Exception e)
				{
					SimStateDudes_Little_Helper.Debug.ShowException(e);
				}
			}
			return true;
		}
	}
	
	//MODIFY PRICE.
	public class ModifyCost : ImmediateInteraction<Sim, Sims3.Gameplay.Abstracts.GameObject>
	{
		private sealed class Definition : ImmediateInteractionDefinition<Sim, IGameObject, ModifyCost>
		{
			public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business:ChangePrice", new object[0]);
			}

			public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				isAutonomous = false;
				if (Employees.CheckIfEmployeeHasRole(a.LotCurrent.LotId,a, Employees.EmployeeRoles.Manager))
				{
					return true;
				}
				else
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
					return false;
				}
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			//POP UP TO ASK FOR NEW PRICE.
			string newCost = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/Business:ChangeCostDialog", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/Business:ChooseCostDialog", new object[0]),"",true);
			int result;
			int.TryParse(newCost, out result);
			if (result > 0)
			{
				Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[base.Target.ObjectId].SetObjectCost(result);
			}
			else if (result < 0)
			{
				Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[base.Target.ObjectId].SetObjectCost(0);
			}
			return true;
		}
	}
	
	//STOP THIEF!
	public class StopThief : ImmediateInteraction<Sim, Sim>
	{
		private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, StopThief>//, IOverridesVisualType
		{
			//public InteractionVisualTypes GetVisualType => InteractionVisualTypes.Opportunity;
			
			public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business:StopThief!", new object[0]);
			}

			public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				isAutonomous = false;
				if (Employees.CheckIfEmployedHere(target.LotCurrent.LotId,a))
				{
					return true;
				}
				else
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YouDontWorkHere", new object[0]));
					return false;
				}
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			CaughtSituation.Create(base.Target.LotCurrent,base.Target, TNSNames.BustedPerformingStreetArt);
			SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/StopThief:CaughtThief", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
			return true;
		}
	}
	
	//BUY INTERACTION.
	public class BuyObject : Interaction<Sim, Sims3.Gameplay.Abstracts.GameObject>
	{
		private sealed class Definition : InteractionDefinition<Sim, IGameObject, BuyObject>
		{
			public override string GetInteractionName(Sim a, IGameObject target, InteractionObjectPair interaction)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Business:BuyNewObject", new object[2] {target.GetLocalizedName(),Core.ownedBusinessdDict[target.LotCurrent.LotId].GetObjectsForSale()[target.ObjectId].GetObjectCost().ToString()});
			}

			public override bool Test(Sim a, IGameObject target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
			{
				if (Core.ownedBusinessdDict.ContainsKey(target.LotCurrent.LotId) && Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessOpenClose() != true)
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/StopThief:BusinessIsClosed", new object[1] {Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessName()}));
					return false;
				}
				else if (Core.powerSurgeDict.ContainsKey(target.LotCurrent.LotId) && Core.powerSurgeDict[target.LotCurrent.LotId] == true)
				{
					greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:NoPurchasesInPowerCut", new object[0]));
					return false;
				}
				else if (isAutonomous && a.IsInActiveHousehold || isAutonomous && Employees.CheckIfEmployedHere(target.LotCurrent.LotId,a) || isAutonomous && a.BuffManager.HasElement(BuffNames.NewStuff))
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		}

		public static readonly InteractionDefinition Singleton = new Definition();

		public override bool Run()
		{
			//Price of item purchase including markup.
			int price = Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[base.Target.ObjectId].GetObjectCost();
			
			//Complimentary profit boost at rank level 5!
			if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessLevel() == 5)
			{
				price = price + (price * 100 / 3);
			}
			
			//Route to the object.
			if (base.Actor.RouteToObjectRadialRangeAndCheckInUse(base.Target, 0.5f, 2f) && base.Target.IsSafeToDelete())
			{
				//Add to inventory - add unique version destroy the missing options version.
				if (base.Actor.IsInActiveHousehold)
				{
					base.Actor.PlaySoloAnimation("a_genericSwipe_pickUp_counter_x");
					//Simoleon visual effect!
					VisualEffect visualEffect = VisualEffect.Create("store_rugPurchase");
					Vector3 trans = Vector3.Zero;
					Vector3 axis = Vector3.Zero;
					if (Slots.AttachToBone(visualEffect.ObjectId, Target.ObjectId, ResourceUtils.HashString32("transformBone"),false,ref trans, ref axis, 0f) == TransformParentingReturnCode.Success)
					{
						visualEffect.SetAutoDestroy(destroy: true);
						visualEffect.Start();
					}
					else
					{
						visualEffect.Dispose();
					}
					
					try {
						
						//Clone the object to give to the player.
						IGameObject gameObject = Sims3.Gameplay.GlobalFunctions.CreateObjectOutOfWorld(base.Target.GetResourceKey());
					
						//Set to whichever inventory the object gets sent too, affects the UI popup after the transaction.
						bool simInventory = true;
						
						//Try to add to the sims inventory if not add to the family inventory, if not a buy mode object remove object from the world & give original.
						if (Business.CheckSimInventory(base.Target))
						{
							Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:ReceiptSimInventoryTrue", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(), base.Target.GetLocalizedName(), price.ToString()}),StyledNotification.NotificationStyle.kSystemMessage);
						}
						else if (gameObject != null && base.Actor.Household.SharedFamilyInventory.Inventory.TryToAdd((GameObject)gameObject))
						{
							Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:ReceiptSimInventoryFalse", new object[] {Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(), base.Target.GetLocalizedName(), price.ToString()}),StyledNotification.NotificationStyle.kSystemMessage);
							simInventory = false;
						}
						
						//Credit owning household if the lot is an owned business.
						if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
						{
							//Remove funds if successfully added!
							base.Actor.ModifyFunds(-price);
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(price);
							//Add to profit tracker.
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddBusinessProfit(price);
							//Object restockable!
							if (simInventory == false)
							{
								Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[base.Target.ObjectId].SetObjectSold(true);
								base.Target.SetOpacity(0.5f,0f);
								base.Target.mIntPrice = 0;
								//Update object to red color.
								if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
								{
									base.Target.SetColorTint(100f,0f,0f,0f);
								}
							}
							else
							{
								base.Target.SetOpacity(1f,0f);
								base.Target.SetColorTint(100f,100f,100f,0f);
								Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().Remove(base.Target.ObjectId);
							}
							//Add XP. Sale price divided by 10.
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddBusinessXP(price / 10);
							Business.CheckCustomerSatisfaction(base.Actor, base.Target.Cost, price);
							
							if (simInventory == true)
							{
								base.Target.RemoveAllInteractions();
								//Add normal interactions back to the object:
								foreach(InteractionObjectPair interaction in gameObject.Interactions)
								{
									if (interaction.CheckIfInteractionValid())
									{
										//Add all the valid interactions!
										base.Target.AddInteraction(interaction.InteractionDefinition);
									}
								}
								base.Actor.Inventory.TryToAdd(base.Target);
								gameObject.Destroy();
							}
							else
							{
								base.Target.RemoveAllInteractions();
								//Add the restock interaction.
								base.Target.AddInteraction(RestockObject.Singleton);
							}
							base.Actor.BuffManager.AddBuff(BuffNames.NewStuff, 0, 60f, false, MoodAxis.Fulfilled, Origin.FromNewObjects, false);
						}
					}
					catch (Exception e)
					{
						SimStateDudes_Little_Helper.Debug.ShowException(e);
					}
				}
				else if (!base.Actor.IsInActiveHousehold && !Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees().ContainsKey(base.Actor.SimDescription))
				{
					//Random yes/no chance of buying.
					int autoBuyChance = RandomUtil.GetInt(1,Business.GetBuyChance(price));
					bool willBuy = false;
					//Even if the price chance is accepted it must still be below the maximum markup for a purchase to succeed.
					if (autoBuyChance == 1)
					{
						//Sim will purchase objects that have a null base price.
						if (base.Target.Cost <= 0)
						{
							willBuy = true;
						}
						else if (price > base.Target.Cost + (base.Target.Cost/100) * Business.GetRankMarkupMax(base.Actor.LotCurrent.LotId) && base.Target.Cost > 0)
						{
							willBuy = false;
						}
						else
						{
							willBuy = true;
						}
					}
					if (willBuy)
					{
						//Credit owning household if the lot is an owned business.
						if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
						{
							if (!Business.CheckIfMysteryShopper(base.Actor))
							{
								//CHECK IF A THIEF ELSE ALLOW THE OBJECT TO BE RESTOCKED.
								if (Business.CheckIfThief(base.Target.LotCurrent.LotId, base.Actor) && !Employees.CheckIfEmployedHere(base.Target.LotCurrent.LotId,base.Actor))
								{
									base.Actor.PlaySoloAnimation("a_genericSwipe_pickUp_counter_x");
									if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessPoints() >= 1 && Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].businessSecuritySystem != true)
									{
										Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveBusinessPoints(1);
									}
									
									Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().Remove(base.Target.ObjectId);
									//Add thief to dictionary.
									Core.thiefDict.Add(base.Actor.SimDescription,true);
									//Add time out alarm.
									AlarmManager.Global.AddAlarm(15f,TimeUnit.Minutes,SimStateDudes_SimState.EventManager.OnThiefCaughtCheck,"Sim State Thief Caught Check", AlarmType.AlwaysPersisted,null);
									Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:ThiefInStore", new object[0]),StyledNotification.NotificationStyle.kGameMessageNegative);
									base.Actor.InteractionQueue.CancelAllInteractions();
									//Insurance payout if the user has the security system!
									if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].businessSecuritySystem == true)
									{
										Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(base.Target.mIntPrice / 2);
										Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:InsurancePayout", new object[] {base.Target.mIntPrice / 2}),StyledNotification.NotificationStyle.kGameMessagePositive);
									}
									base.Target.SetObjectToReset();
									base.Target.RemoveFromWorld();
								}
								else
								{
									//SET OBJECT TO NEEDING RESTOCK STATUS.
									try
									{
										base.Actor.PlaySoloAnimation("a_genericSwipe_pickUp_counter_x");
										
										//Simoleon visual effect!
										VisualEffect visualEffect = VisualEffect.Create("store_rugPurchase");
										Vector3 trans = Vector3.Zero;
										Vector3 axis = Vector3.Zero;
										if (Slots.AttachToBone(visualEffect.ObjectId, Target.ObjectId, ResourceUtils.HashString32("transformBone"),false,ref trans, ref axis, 0f) == TransformParentingReturnCode.Success)
										{
											visualEffect.SetAutoDestroy(destroy: true);
											visualEffect.Start();
										}
										else
										{
											visualEffect.Dispose();
										}
										
										//Online advertising campaign random sponser!
										if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAdvertOnline() > 0)
										{
											int sponserRnd = RandomUtil.GetInt(1,10);
											if (sponserRnd == 1)
											{
												int sponserAmount = RandomUtil.GetInt(1,300);
												Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(sponserAmount);
												SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/BuyObject:Sponser", new object[] {sponserAmount.ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
											}
										}
										
										Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(price);
										//Add to profit tracker.
										Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddBusinessProfit(price);
										//Add XP. Sale price divided by 10 unless an active TV AD is in place!
										if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAdvertTV() > 0)
										{
											Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddBusinessXP(price / 5);
											//Add free customer satisfaction points!
											int rndChance = RandomUtil.GetInt(1,10);
											if (rndChance == 1)
											{
												int customerSatisfactionRnd = RandomUtil.GetInt(2,5);
												Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddBusinessPoints(customerSatisfactionRnd);
												SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/BuyObject:TVCustomerSatisfactionBoost", new object[] {customerSatisfactionRnd.ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
											}
										}
										else
										{
											Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddBusinessXP(price / 10);
										}
										//Add break in sales buff!
										base.Actor.BuffManager.AddBuff(BuffNames.NewStuff, 0, 60f, false, MoodAxis.Fulfilled, Origin.FromNewObjects, false);
										
										Business.CheckCustomerSatisfaction(base.Actor, base.Target.Cost, price);
																				
										//Rank level 5 random compliments!
										if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessLevel() == 5)
										{
											int chanceOfCompliment = RandomUtil.GetInt(1,25);
											if (chanceOfCompliment == 1)
											{
												int rnd = RandomUtil.GetInt(1,2);
												if (rnd == 1)
												{
													Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:WhatAnAmazingStore", new object[3] {base.Actor.GetLocalizedName(),base.Target.GetLocalizedName(),price.ToString()}),StyledNotification.NotificationStyle.kGameMessagePositive);
												}
												else
												{
													Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:WhatAnAmazingStore1", new object[1] {base.Actor.GetLocalizedName()}),StyledNotification.NotificationStyle.kGameMessagePositive);
												}
											}
										}
										
										//If the item is not family inventory size automatically 'delete' it on purchase.
										if (Business.CheckSimInventory(base.Target))
										{
											base.Target.Destroy();
										}
										else
										{
											//Remove all interactions.
											base.Target.RemoveAllInteractions();
											
											//Add the restock interaction.
											base.Target.AddInteraction(RestockObject.Singleton);
											//Update object to red color.
											if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
											{
												base.Target.SetColorTint(100f,0f,0f,0f);
											}
											
											//Change sold modifier in object class.
											Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[base.Target.ObjectId].SetObjectSold(true);
											base.Target.SetOpacity(0.5f,0f);
											base.Target.mIntPrice = 0;
										}
										
										//Send the Sim home after purchase test.
										int chanceToGoHome = RandomUtil.GetInt(1,5);
										if (chanceToGoHome == 1)
										{
											Sim.MakeSimGoHome(base.Actor, false, new InteractionPriority(InteractionPriorityLevel.High));
										}
									}
									catch(Exception e)
									{
										SimStateDudes_Little_Helper.Debug.ShowException(e);
									}
								}
							}
						}
					}
					//Customers may complain if the purchase price is above 25%.
					else if (price > base.Target.Cost + (base.Target.Cost/100) * Business.GetRankMarkupMax(base.Actor.LotCurrent.LotId))
					{
						int complainAboutPriceChance = RandomUtil.GetInt(1,75);
						//Frugal sims are WAY more likely to complain.
						if (base.Actor.TraitManager.HasElement(TraitNames.Frugal))
						{
						   complainAboutPriceChance = RandomUtil.GetInt(1,10);
						}
						if (complainAboutPriceChance == 1 && Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessLevel() <= 4)
						{
							Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:ObjectTooExpensiveDialog", new object[3] {base.Actor.GetLocalizedName(),base.Target.GetLocalizedName(),price.ToString()}),StyledNotification.NotificationStyle.kGameMessageNegative);
						}
					}
				}
			}
			else
			{
				base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:SomeoneUsingObject", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
			}
			return true;
		}
	}
}
