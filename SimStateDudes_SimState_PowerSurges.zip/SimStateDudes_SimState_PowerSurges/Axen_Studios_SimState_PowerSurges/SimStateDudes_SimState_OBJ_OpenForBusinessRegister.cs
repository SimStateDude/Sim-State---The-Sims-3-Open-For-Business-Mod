﻿/*
 * Created by SharpDevelop.
 * User: Nytician
 * Date: 28/02/2021
 * Time: 16:02
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using SimStateDudes_SimState;
using Sims3.SimIFace;
using Sims3.SimIFace.BuildBuy;
using Sims3.Gameplay.Objects.Register;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Interfaces;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.Autonomy;
using Sims3.Gameplay.Services;
using Sims3.Gameplay.Careers;
using Sims3.UI;
using Sims3.Gameplay.Abstracts;
using Sims3.UI.Dialogs;
using Sims3.Gameplay.Utilities;
using Sims3.Gameplay.Objects.Electronics;
using Sims3.Gameplay.CAS;
using Sims3.Gameplay.Objects.Counters;
using Sims3.SimIFace.CustomContent;

namespace Sims3.Gameplay.Objects.Register.SSD_SimState
{
	/// <summary>
	/// Description of SimStateDudes_SimState_OBJ_OpenForBusinessRegister.
	/// </summary>
	public class OBJ_OpenForBusinessRegister : GameObject, ICounterSurfaceAppliance, IGameObject, IScriptObject, IScriptLogic, IHasScriptProxy, IObjectUI, IExportableContent
	{
		
		//Displays the business overview UI dialog. (See Core)
		public sealed class ShowBusinessStats : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.ShowBusinessStats>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ShowBusinessInfo", new object[0]);
                }
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployedHere(base.Target.LotCurrent.LotId,base.Actor))
            		{
            			try
            			{
            				SimStateDudes_SimState.Core.BusinessReviewDialog.Show(base.Target.LotCurrent.LotId);
            			}
            			catch(Exception e)
            			{
            				SimStateDudes_Little_Helper.Debug.ShowException(e);
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YouDontWorkHere", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
		}
		
		//Allows the player to set the opening time.
		public sealed class OpeningTime : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.OpeningTime>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                    return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:SetOpeningTime", new object[0]);
                }
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			string businessOpeningTime = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/OFB_OpenForBusinessRegister:SetOpenTime", new object[1] {SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),Localization.LocalizeString("SimStateDudes/SimState/OFB_OpenForBusinessRegister:SetOpenTimeText", new object[0]),"",true);
            			int result;
						int.TryParse(businessOpeningTime, out result);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].SetBusinessOpening(result);
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Allows the player to set the closing time.
		public sealed class ClosingTime : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.ClosingTime>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                    return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:SetClosingTime", new object[0]);
                }
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			string businessClosingTime = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/OFB_OpenForBusinessRegister:SetCloseTime", new object[1] {SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()}),Localization.LocalizeString("SimStateDudes/SimState/OFB_OpenForBusinessRegister:SetCloseTimeText", new object[0]),"",true);
            			int result;
						int.TryParse(businessClosingTime, out result);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].SetBusinessClosing(result);
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Displays the amount of business points the business has.
		public sealed class BusinessRewardPoints : Interaction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : InteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.BusinessRewardPoints>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:CustomerSatisfactionPoints", new object[] {SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessPoints().ToString()});
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewards...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                	greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:CurrentBusinessPointsAvailable", new object[0]));
                    return false;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			//REWARDS GO HERE!
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Allows the player to gain a 1k award once they achieve 10 points.
		public sealed class BusinessReward1k : Interaction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : InteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.BusinessReward1k>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:$1000CashReward", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewards...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                	if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessPoints() >= 10)
                	{
                		if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].businessReward1k == false)
                		{
                			return true;
                		}
                		else
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:AlreadyPurchased", new object[0]));
                			return false;
                		}
                	}
                	else
                	{
                		if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].businessReward1k == false)
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:NotEnoughPoints10", new object[0]));
                    		return false;
                		}
                		else
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:AlreadyPurchased", new object[0]));
                			return false;
                		}
                	}
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			//REWARDS GO HERE!
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:Purchased1kReward", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(1000);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveBusinessPoints(10);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].businessReward1k = true;
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		public sealed class BusinessReward5k : Interaction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : InteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.BusinessReward5k>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:$5000CashReward", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewards...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                	if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessPoints() >= 50)
                	{
                		if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].businessReward5k == false)
                		{
                			return true;
                		}
                		else
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:AlreadyPurchased", new object[0]));
                			return false;
                		}
                	}
                	else
                	{
                		if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].businessReward5k == false)
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:NotEnoughPoints50", new object[0]));
                    		return false;
                		}
                		else
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:AlreadyPurchased", new object[0]));
                			return false;
                		}
                	}
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			//REWARDS GO HERE!
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:Purchased5kReward", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddToBusinessAccount(5000);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveBusinessPoints(50);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].businessReward5k = true;
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Affects the criteria for thieves and auto-calls the police on theft.
		public sealed class BusinessRewardSecuritySystem : Interaction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : InteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.BusinessRewardSecuritySystem>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewardSecuritySystem", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewards...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                	if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessPoints() >= 50)
                	{
                		if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].businessSecuritySystem == false)
                		{
                			return true;
                		}
                		else
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:AlreadyPurchased", new object[0]));
                			return false;
                		}
                	}
                	else
                	{
                		if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].businessSecuritySystem == false)
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:NotEnoughPoints50", new object[0]));
                    		return false;
                		}
                		else
                		{
                			greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:AlreadyPurchased", new object[0]));
                			return false;
                		}
                	}
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			//REWARDS GO HERE!
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:PurchasedSecuritySystemReward", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveBusinessPoints(50);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].businessSecuritySystem = true;
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		public sealed class BusinessRewardSuperRestock : Interaction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : InteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.BusinessRewardSuperRestock>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewardSuperRestock", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:BusinessRewards...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                	if (SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessPoints() >= 25)
                	{
                		return true;
                	}
                	else
                	{
                		greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:NotEnoughPoints25", new object[0]));
                    	return false;
                	}
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			//REWARDS GO HERE!
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ActivatedSuperRestockReward", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveBusinessPoints(25);
            			
            			if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            			{
            				int count = 0;
            				foreach(KeyValuePair<ObjectGuid, ObjectForSale> obj in SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale())
            				{
            					GameObject restockObj = GetObject(obj.Key);
            					if (!SimStateDudes_SimState.Business.CheckSimInventory(restockObj) && obj.Value.GetObjectSold())
            					{
            						BuildBuyProduct product = restockObj.Product;
            						restockObj.mIntPrice = ((!(product == null)) ? ((int)product.Price) : 0);
            						if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() >= restockObj.mIntPrice)
            						{
            							restockObj.RemoveAllInteractions();
            							
            							//ADD THE BUY INTERACTION.
            							SimStateDudes_SimState.Business.SetForSaleInteraction(restockObj);
            							//ADD THE REMOVE INTERACTION.
            							SimStateDudes_SimState.Business.RemoveFromSaleInteraction(restockObj);
            							//ADD THE MODIFY COST INTERACTION.
            							restockObj.AddInteraction(ModifyCost.Singleton);
            							
            							//CHANGE COLOR BACK TO GREEN.
            							if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
            							{
            								restockObj.SetColorTint(0f,100f,0f,0f);
            							}
            							
            							restockObj.SetOpacity(1f,0f);
            							
            							if (restockObj.mIntPrice > 0)
            							{
            								SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].RemoveFromBusinessAccount(restockObj.mIntPrice);
            							}
            							
            							//Set as unsold again.
            							SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[restockObj.ObjectId].SetObjectSold(false);
            							
            							//Set 5% markup.
            							SimStateDudes_SimState.Business.CalculateMarkupAndSetForSale(restockObj);
            							Repoman.FireTeleportEffect(restockObj);
            						}
            						else
            						{
            							//Not enough money to restock, stop the whole process and show error message.
            							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Restock:NotEnoughMoney", new object[] {base.Target.GetLocalizedName(), base.Target.mIntPrice.ToString(), SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
										SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().Remove(restockObj.ObjectId);
										restockObj.Destroy();
            							break;
            						}
            					}
            					//Break after 10 objects are restocked!
            					if (count < 10)
            					{
            						count++;	
            					}
            					else
            					{
            						break;
            					}
            				}
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Allows the player to 'hire' employees from the town.
		public sealed class HireEmployee : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.HireEmployee>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:HireEmployees", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ManageEmployees...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor,Employees.EmployeeRoles.Manager))
            		{
            			try
            			{
            				if (SimStateDudes_SimState.Business.GetMaxEmployees(SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessLevel()) > 0)
            				{
            					if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees().Count < SimStateDudes_SimState.Business.GetMaxEmployees(SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessLevel()))
            					{
            						List<PhoneSimPicker.SimPickerInfo> simList = new List<PhoneSimPicker.SimPickerInfo>();
            						foreach (Household household in Household.GetHouseholdsLivingInWorld())
            						{
            							foreach (SimDescription simDescription in household.SimDescriptions)
            							{
            								if (!simDescription.IsPet && simDescription.YoungAdultOrAbove && !Employees.CheckIfEmployed(simDescription))
            								{
            									simList.Add(Phone.Call.CreateBasicPickerInfo(base.Actor.SimDescription, simDescription));
            								}
            							}
            						}
            						
            						List<object> pickedSimList = new List<object>();
            						SimDescription pickedSim;
            						pickedSimList = PhoneSimPicker.Show(true,ModalDialog.PauseMode.PauseSimulator,simList,Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:HireEmployees", new object[0]),"","",1,false);
            						
            						if (pickedSimList != null)
            						{
            							pickedSim = pickedSimList[0] as SimDescription;
            							
            							if (pickedSim.CareerManager.Occupation != null)
            							{
            								pickedSim.CareerManager.Occupation.RetireNoConfirmation();
            							}
            							else
            							{
            								//Add new unemployed retire code here...hmmm...
            							}
            							
            							//Add employee interactions if on the lot already.
            							if (SimDescription.GetCreatedSim(pickedSim.SimDescriptionId).LotCurrent.LotId == base.Target.LotCurrent.LotId)
            							{
            								Employees.AddEmployeeInteractions(base.Target.LotCurrent.LotId);
            							}
            							SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].AddNewEmployee(pickedSim);
            							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister/HireEmployee:Hired", new object[] {SimDescription.GetCreatedSim(pickedSim.SimDescriptionId).GetLocalizedName()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            						}
            					}
            					else
            					{
            						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister/HireEmployee:MaximumEmployeesAllowed", new object[] {SimStateDudes_SimState.Business.GetMaxEmployees(SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessLevel())} ),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            					}
            				}
            				else
            				{
            					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister/HireEmployee:NoEmployeesAllowed", new object[0] ),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            				}
            				
            			}
            			catch(Exception e)
            			{
            				SimStateDudes_Little_Helper.Debug.ShowException(e);
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Shows the current employees in the business.
		public sealed class ShowEmployees : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.ShowEmployees>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ShowEmployeeInfo", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ManageEmployees...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployedHere(base.Target.LotCurrent.LotId,base.Actor))
            		{
            			try
            			{
            				List<PhoneSimPicker.SimPickerInfo> simList = new List<PhoneSimPicker.SimPickerInfo>();
            				foreach (KeyValuePair <SimDescription, Business_Employees> employee in SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees())
            				{
            					simList.Add(Phone.Call.CreateBasicPickerInfo(base.Actor.SimDescription, employee.Value.GetSimDescription()));
            				}
            				List<object> pickedSimList = new List<object>();
            				SimDescription pickedSim;
            				pickedSimList = PhoneSimPicker.Show(true,ModalDialog.PauseMode.PauseSimulator,simList,Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:CurrentEmployees", new object[0]),"","",1,false);
          					
            				if (pickedSimList != null)
            				{
            					pickedSim = pickedSimList[0] as SimDescription;
            					Employees.ShowEmployeeInfo(base.Target.LotCurrent.LotId, SimDescription.GetCreatedSim(pickedSim.SimDescriptionId));
            				}
            			}
            			catch(Exception e)
            			{
            				SimStateDudes_Little_Helper.Debug.ShowException(e);
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YouDontWorkHere", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Allows you to remove/fire employees via the till!
		public sealed class RemoveEmployees : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.RemoveEmployees>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:RemoveEmployee", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ManageEmployees...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployedHere(base.Target.LotCurrent.LotId,base.Actor))
            		{
            			if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor,Employees.EmployeeRoles.Manager))
            			{
            			
            				try
            				{
            					int managerCount = 0;
            					List<PhoneSimPicker.SimPickerInfo> simList = new List<PhoneSimPicker.SimPickerInfo>();
            					foreach (KeyValuePair <SimDescription, Business_Employees> employee in SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees())
            					{
            						simList.Add(Phone.Call.CreateBasicPickerInfo(base.Actor.SimDescription, employee.Value.GetSimDescription()));
            						if (employee.Value.GetEmployeeRole() == Employees.EmployeeRoles.Manager)
            						{
            							managerCount++;
            						}
            					}
            					List<object> pickedSimList = new List<object>();
            					SimDescription pickedSim;
            					pickedSimList = PhoneSimPicker.Show(true,ModalDialog.PauseMode.PauseSimulator,simList,Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:CurrentEmployees", new object[0]),"","",1,false);
            					
            					if (pickedSimList != null)
            					{
            						pickedSim = pickedSimList[0] as SimDescription;
            						if (simList.Count >= 2)
            						{
            							//Check if the employee set to be removed is a manager and if so make sure there is more than one manager at the store!
            							if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[pickedSim].GetEmployeeRole() != Employees.EmployeeRoles.Manager || SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[pickedSim].GetEmployeeRole() == Employees.EmployeeRoles.Manager && managerCount > 1)
            							{
            								Employees.ShowEmployeeFiredMessage(base.Target.LotCurrent.LotId,SimDescription.GetCreatedSim(pickedSim.SimDescriptionId));
            								Employees.RemoveEmployeeInteractions(base.Target.LotCurrent.LotId,pickedSim);
            								Employees.GiveSeverancePay(base.Target.LotCurrent.LotId, SimDescription.GetCreatedSim(pickedSim.SimDescriptionId));
            								if (SimDescription.GetCreatedSim(pickedSim.SimDescriptionId).LotCurrent.LotId == base.Target.LotCurrent.LotId)
            								{
            									Sim.MakeSimGoHome(SimDescription.GetCreatedSim(pickedSim.SimDescriptionId),false);
            								}
            								//Remove sim from business record.
            								SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees().Remove(pickedSim);
            							}
            							else
            							{
            								//You can't fire all the managers!
											SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:YouCannotFireAllManagers", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            							}
            						}
            						else
            						{
            							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:YouCannotFireAllManagers", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            						}
            					}
            				}
            				catch(Exception e)
            				{
            					SimStateDudes_Little_Helper.Debug.ShowException(e);
            				}
            			}
            			else
            			{
            				base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YouDontWorkHere", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Opens the business.
		public sealed class OpenClose : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.OpenClose>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:Open/Close", new object[] {SimStateDudes_SimState.Core.ownedBusinessdDict[target.LotCurrent.LotId].GetBusinessName()});
                }
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor,Employees.EmployeeRoles.Manager))
            		{
            			string openClose;
            			if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessOpenClose())
            			{
            				openClose = Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:Closed", new object[0]);
            				//Send all staff & customers home.
            				Sim[] sims = Sims3.Gameplay.Queries.GetObjects<Sim>(base.Target.LotCurrent);
            				foreach(Sim sim in sims)
            				{
            					if (!sim.IsInActiveHousehold && !sim.Household.IsServiceNpcHousehold && !sim.Household.IsPetHousehold && !sim.Household.IsServobotHousehold)
            					{
            						sim.InteractionQueue.CancelAllInteractions();
            						Sim.MakeSimGoHome(sim,true);
            					}
            				}
            				SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].SetBusinessOpenClose();
            				base.Actor.ShowTNSIfSelectable(SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()+" is now "+openClose+"!", StyledNotification.NotificationStyle.kGameMessagePositive);
            			}
            			else if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() >= 1)
            			{
            				openClose = Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:Open", new object[0]);
            				SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].SetBusinessOpenClose();
            				base.Actor.ShowTNSIfSelectable(SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName()+" is now "+openClose+"!", StyledNotification.NotificationStyle.kGameMessagePositive);
            			}
            			else if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount() <= 0)
            			{
            				Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:NoMoneyToOpen", new object[] {SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessName(), SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetBusinessAccount().ToString()}),StyledNotification.NotificationStyle.kSystemMessage);
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Calls in any employees!
		public sealed class CallEmployees : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.CallEmployees>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:CallEmployees", new object[0]);
                }
                
                public override string[] GetPath(bool isFemale)
				{
					return new string[] {Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ManageEmployees...", new object[0])};
				}
                
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor,Employees.EmployeeRoles.Manager))
            		{
            			foreach(KeyValuePair<SimDescription, Business_Employees> employee in SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees())
            			{
            				//Reset sent home status.
            				if(employee.Value.GetEmployeeSentHome())
            				{
            					employee.Value.ResetSentHome();
            				}
            				Sim sim = SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId);
            				Employees.CallInEmployees(base.Target.LotCurrent.LotId, sim, false);
            			}
            			SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister/CallInEmployees:Called", new object[0] ),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Shows/hides the set for sale overlay.
		public sealed class EnableSetForSale : ImmediateInteraction<Sim, OBJ_OpenForBusinessRegister>
        {
            public static readonly InteractionDefinition Singleton = new Definition();

            private sealed class Definition : ImmediateInteractionDefinition<Sim, OBJ_OpenForBusinessRegister, OBJ_OpenForBusinessRegister.EnableSetForSale>
            {
                public override string GetInteractionName(Sim a, OBJ_OpenForBusinessRegister target, InteractionObjectPair interaction)
                {
                	return Localization.LocalizeString("SimStateDudes/SimState/OBJ_OpenForBusinessRegister:ToggleSetForSale", new object[0]);
                }
                public override bool Test(Sim a, OBJ_OpenForBusinessRegister target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                    return !isAutonomous;
                }
            }
            
            public override bool Run()
            {
            	if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
            	{
            		if (Employees.CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Actor, Employees.EmployeeRoles.Manager))
            		{
            			SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].SetEnableSetForSale();
            			if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetEnableSetForSale())
            			{
            				SimStateDudes_SimState.Business.AddSetForSaleInteraction(base.Target.LotCurrent);
            				//Change all household objects to yellow tint.
            				GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(base.Target.LotCurrent);
            				foreach (GameObject obj in objects)
            				{
            					if (SimStateDudes_SimState.Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId) && SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale().ContainsKey(obj.ObjectId))
            					{
            						if (SimStateDudes_SimState.Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetObjectsForSale()[obj.ObjectId].GetObjectSold())
            						{
            							obj.SetOpacity(0.5f,0f);
            							//Red
            							obj.SetColorTint(100f,0f,0f,0f);
            						}
            						else
            						{
            							//Green
            							obj.SetColorTint(0f,100f,0f,0f);
            						}
            					}
            					else
            					{
            						obj.SetColorTint(100f,100f,0f,0f);
            					}
            				}
            			}
            			else
            			{
            				SimStateDudes_SimState.Business.RemoveSetForSaleInteraction(base.Target.LotCurrent);
            				//Change all household objects to normal color.
            				GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(base.Target.LotCurrent);
            				foreach (GameObject obj in objects)
            				{
            					//Reverts to the default color.
            					obj.SetColorTint(100f,100f,100f,0f);
            				}
            			}
            		}
            		else
            		{
            			base.Actor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
            		}
            	}
            	return true;
            }
        }
		
		//Adds all of the interactions to the till.
        public override void OnStartup()
        {
            base.AddInteraction(ShowBusinessStats.Singleton);
            base.AddInteraction(OpeningTime.Singleton);
            base.AddInteraction(ClosingTime.Singleton);
            base.AddInteraction(OpenClose.Singleton);
            base.AddInteraction(EnableSetForSale.Singleton);
            base.AddInteraction(BusinessRewardPoints.Singleton);
            base.AddInteraction(HireEmployee.Singleton);
            base.AddInteraction(RemoveEmployees.Singleton);
            base.AddInteraction(ShowEmployees.Singleton);
            base.AddInteraction(CallEmployees.Singleton);
            
            //BUSINESS REWARDS!
            base.AddInteraction(BusinessReward1k.Singleton);
            base.AddInteraction(BusinessReward5k.Singleton);
            base.AddInteraction(BusinessRewardSecuritySystem.Singleton);
            base.AddInteraction(BusinessRewardSuperRestock.Singleton);
        }
	}
}
