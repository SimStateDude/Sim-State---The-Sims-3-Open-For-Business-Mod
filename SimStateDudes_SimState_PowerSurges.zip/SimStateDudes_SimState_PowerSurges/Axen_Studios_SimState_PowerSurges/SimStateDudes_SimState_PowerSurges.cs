﻿//SimStateDudes - Sim State - Power Surges Module
using System;
using System.Collections.Generic;
using System.Text;
using Sims3.SimIFace;
using Sims3.SimIFace.Enums;
using Sims3.Gameplay;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Utilities;
using Sims3.Gameplay.Core;
using Sims3.UI;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.Objects;
using Sims3.Gameplay.Objects.Lighting;
using Sims3.Gameplay.Objects.Electronics;
using Sims3.Gameplay.Objects.Appliances;
using Sims3.Gameplay.Autonomy;
using Sims3.Gameplay.ObjectComponents;
using Sims3.Gameplay.CAS;
using Sims3.Gameplay.Seasons;

namespace SimStateDudes_SimState
{
	/// <summary>
	/// Description of MyClass.
	/// </summary>
	public class PowerSurges
	{
		//Amount of times the surge manager has been run. Resets every hour and randomly checks to stop surge for active household.
		private static int timeCheck = 0;
		//Maximum random chance multiplier of surge ending.
		private static int maximumSurgeEnd = 1;
		//Chance of thunderstorm surge happening.
		private static int thunderStormSurgeChance = 5;
		//Is it currently hailing...
		private static bool currentlyHailing = false;
        
        public PowerSurges()
        {
        	//Periodically check for any updates.
        	AlarmManager.Global.AddAlarmRepeating(1f, TimeUnit.Minutes, new AlarmTimerCallback(SurgeManager), 10f, TimeUnit.Minutes, "Surge Manager", AlarmType.NeverPersisted, null);
        }

        private static void SurgeManager()
        {
        	//When to perform a power surge.
        	try
        	{
        		
        		//Did the player save with a power cut in progress?
        		if (SimStateDudes_SimState.Core.powerSurgeDict.ContainsKey(Sim.ActiveActor.LotHome.LotId))
        		{
        			if (SimStateDudes_SimState.Core.powerSurgeDict[Sim.ActiveActor.LotHome.LotId] == true)
        			{
        				//Increment time check until 6 before starting fresh for new hour.
        				timeCheck++;
        				//Ensure set interactions remain disabled.
        				if (timeCheck >= 6)
        				{
        					//Reset time check.
        					timeCheck = 0;
        					Random rnd = new Random();
        					//Random chance of the surge being over.
        					if (rnd.Next(1,maximumSurgeEnd) == maximumSurgeEnd)
        					{
        						StopSurge();
        					}
        				}
        			}
        		}
        		
        		if (Sims3.Gameplay.Seasons.SeasonsManager.CurrentWeather == Weather.Hail)
        		{
        			Random rnd = new Random();
        			//Add the houseid to the dictionary if it doesn't already contain it.
        			if (!SimStateDudes_SimState.Core.powerSurgeDict.ContainsKey(Sim.ActiveActor.LotHome.LotId) && currentlyHailing == false)
        			{
        				//Stop power surges happening over and over again during hail.
        				currentlyHailing = true;
        				SimStateDudes_SimState.Core.powerSurgeDict.Add(Sim.ActiveActor.LotHome.LotId,false);
        				if (rnd.Next(1,thunderStormSurgeChance) == thunderStormSurgeChance)
        				{
        					StartSurge();
        				}
        			}
        		}
        		else
        		{
        			currentlyHailing = false;
        		}
        		
        	}
        	catch (Exception e)
        	{
        		SimStateDudes_Little_Helper.Debug.ShowException(e);
        	}
        }
        
        private static void StartSurge()
        {
        	//Stops the player experiencing more than one powercut!
        	if (SimStateDudes_SimState.Core.powerSurgeDict.ContainsKey(Sim.ActiveActor.LotHome.LotId) && SimStateDudes_SimState.Core.powerSurgeDict[Sim.ActiveActor.LotHome.LotId] == false)
        	{
        		//Reset time.
        		timeCheck = 0;
        		//Set power surge to true.
        		SimStateDudes_SimState.Core.powerSurgeDict[Sim.ActiveActor.LotHome.LotId] = true;
        		
        		//Inform player that they are now experiencing a powercut!
        		Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/PowerSurges:OhNo", new object[0]), StyledNotification.NotificationStyle.kGameMessageNegative);
        		//Random number generator.
        		Random rnd = new Random();
        		//Random chance of objects breaking due to the surge.
        		int breakChance;
        		
        		//Power down rabbitholes!
        		RabbitHole[] rabbitHoles = Sims3.Gameplay.Queries.GetObjects<RabbitHole>();
        		foreach (RabbitHole rabbitHole in rabbitHoles)
        		{
        			rabbitHole.SetMaterial("Default");
        		}
        		
        		//MEGA STORM, MAY NEED SOME TWEAKING UNCOMMENT TO SEE IT IN ACTION & CHANGE THE RANDOM 1-1000 to a 1-1 ratio to ensure you get one during a power cut! :)
//        		Random rnd2 = new Random();
//        		if (rnd2.Next(1,1000) == 1 && Core.megaStorm == false)
//        		{
//        			
//        			Sim.ActiveActor.ShowTNSIfSelectable("What in Sixam just happened??? The town just experienced some kind of immense once in a lifetime lightning storm! Is everyone alright?", StyledNotification.NotificationStyle.kGameMessageNegative);
//        			Sim[] sims = Sims3.Gameplay.Queries.GetObjects<Sim>();
//        			foreach (Sim sim in sims)
//        			{
//        				Sims3.Gameplay.Objects.Miscellaneous.MeteorShower.TriggerMeteorShowerEvent(sim.Position);
//        			}
//        			Core.megaStorm = true;
//        		}
        		
        		//LIGHTS.
        		LightCeilingLamp[] ceilingLamps = Sims3.Gameplay.Queries.GetObjects<LightCeilingLamp>(Sim.ActiveActor.LotHome);
        		foreach (LightCeilingLamp ceilingLamp in ceilingLamps)
        		{
        			ceilingLamp.SwitchLight(false,true);
        		}
        		
        		LightFloorLamp[] floorLamps = Sims3.Gameplay.Queries.GetObjects<LightFloorLamp>(Sim.ActiveActor.LotHome);
        		foreach (LightFloorLamp floorLamp in floorLamps)
        		{
        			floorLamp.SwitchLight(false,true);
        		}
        		
        		LightWallLamp[] wallLamps = Sims3.Gameplay.Queries.GetObjects<LightWallLamp>(Sim.ActiveActor.LotHome);
        		foreach (LightWallLamp wallLamp in wallLamps)
        		{
        			wallLamp.SwitchLight(false,true);
        		}
        		
        		LightTableLamp[] tableLamps = Sims3.Gameplay.Queries.GetObjects<LightTableLamp>(Sim.ActiveActor.LotHome);
        		foreach (LightTableLamp tableLamp in tableLamps)
        		{
        			tableLamp.SwitchLight(false,true);
        		}
        		
        		LightOutdoor[] outdoorLamps = Sims3.Gameplay.Queries.GetObjects<LightOutdoor>(Sim.ActiveActor.LotHome);
        		foreach (LightOutdoor outdoorLamp in outdoorLamps)
        		{
        			outdoorLamp.SwitchLight(false,true);
        		}
        		
        		TV[] televisions = Sims3.Gameplay.Queries.GetObjects<TV>(Sim.ActiveActor.LotHome);
        		foreach (TV television in televisions)
        		{
        			
        			breakChance = rnd.Next(1,11);
        			
        			if (breakChance == 10)
        			{
        				television.Repairable.BreakObject();
        			}
        			else
        			{
        				television.TurnOff();
        			}
        		}
        		
        		Stereo[] stereos = Sims3.Gameplay.Queries.GetObjects<Stereo>(Sim.ActiveActor.LotHome);
        		foreach (Stereo stereo in stereos)
        		{
        			stereo.TurnOff();
        			
        			breakChance = rnd.Next(1,11);
        			
        			if (breakChance == 10)
        			{
        				stereo.Repairable.BreakObject();
        			}
        		}
        		
        		DisableInteractions();
        	}
        }
        
        private static void DisableInteractions()
        {
        	//Disable interactions on (most)electrical items.
        	GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(Sim.ActiveActor.LotHome);
        	foreach (GameObject obj in objects)
        	{
        		//Electronics, lighting and appliances disabled.
        		if (obj.BuyCategoryFlags == 4u || obj.BuyCategoryFlags == 0x20u || obj.BuyCategoryFlags == 2u)
        		{
        			obj.DisableInteractions(InteractionsDisabledType.All);
        		}
        	}
        	
        }
        
        private static void StopSurge()
        {
        	//All surge code here.
        	Sim.ActiveActor.ShowTNSIfSelectable(Localization.LocalizeString("SimStateDudes/SimState/PowerSurges:PowerBack", new object[0]), StyledNotification.NotificationStyle.kSystemMessage);
        	
        	//Disable PowerSurge Mechanics.
        	//No longer experiencing power surge.
        	SimStateDudes_SimState.Core.powerSurgeDict.Remove(Sim.ActiveActor.LotHome.LotId);
        	
        	//Turn on lighting.
        	LightCeilingLamp[] ceilingLamps = Sims3.Gameplay.Queries.GetObjects<LightCeilingLamp>(Sim.ActiveActor.LotHome);
        	foreach (LightCeilingLamp ceilingLamp in ceilingLamps)
        	{
        		ceilingLamp.SwitchLight(true,true);
        	}
        		
        	LightFloorLamp[] floorLamps = Sims3.Gameplay.Queries.GetObjects<LightFloorLamp>(Sim.ActiveActor.LotHome);
        	foreach (LightFloorLamp floorLamp in floorLamps)
        	{
        		floorLamp.SwitchLight(true,true);
        	}
        		
        	LightWallLamp[] wallLamps = Sims3.Gameplay.Queries.GetObjects<LightWallLamp>(Sim.ActiveActor.LotHome);
        	foreach (LightWallLamp wallLamp in wallLamps)
        	{
        		wallLamp.SwitchLight(true,true);
        	}
        		
        	LightTableLamp[] tableLamps = Sims3.Gameplay.Queries.GetObjects<LightTableLamp>(Sim.ActiveActor.LotHome);
        	foreach (LightTableLamp tableLamp in tableLamps)
        	{
        		tableLamp.SwitchLight(true,true);
        	}
        	
        	LightOutdoor[] outdoorLamps = Sims3.Gameplay.Queries.GetObjects<LightOutdoor>(Sim.ActiveActor.LotHome);
        	foreach (LightOutdoor outdoorLamp in outdoorLamps)
        	{
        		outdoorLamp.SwitchLight(true,true);
        	}
			
			GameObject[] objects = Sims3.Gameplay.Queries.GetObjects<GameObject>(Sim.ActiveActor.LotHome);
			foreach (GameObject obj in objects)
			{
				//Electronics, lighting and appliances reenabled.
				if (obj.BuyCategoryFlags == 4u || obj.BuyCategoryFlags == 0x20u || obj.BuyCategoryFlags == 2u)
				{
					obj.EnableInteractions(InteractionsDisabledType.All);
				}
			}
        }
	}
}