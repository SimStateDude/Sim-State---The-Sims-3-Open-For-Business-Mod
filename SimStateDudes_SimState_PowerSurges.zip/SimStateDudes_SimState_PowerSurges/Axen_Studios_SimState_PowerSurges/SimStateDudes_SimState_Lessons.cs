﻿using System;
using System.Collections.Generic;
using Sims3.UI;
using Sims3.SimIFace;

namespace SimStateDudes_SimState
{
	/// <summary>
	/// Description of Lessons.
	/// </summary>
	public class Lessons
	{
		public Lessons()
		{
			LoadLessons();
		}
		
		private void LoadLessons()
		{
			//LESSON #1 - Welcome.
            List<TutorialetteDialog.TutorialettePage> lesson1Pages = new List<TutorialetteDialog.TutorialettePage>();
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page1","SSLessonWelcome1"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page2","SSLessonWelcome2"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page3","SSLessonWelcome3"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page4","SSLessonWelcome4"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page5","SSLessonWelcome5"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page6","SSLessonWelcome6"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page7","SSLessonWelcome7"));
            lesson1Pages.Add(new TutorialetteDialog.TutorialettePage("SimStateDudes/SimState/Lesson1:Page8","SSLessonWelcome8"));
            
            TutorialetteDialog.TutorialetteData lesson1Data = new TutorialetteDialog.TutorialetteData("SimStateDudes/SimState/Lesson:Name",lesson1Pages,1,1u);
            
            
            
            //LESSON #2 - Sim State ID.
            
            //LESSON #3 - Business Overview.
            
            
            //ADD LESSONS!
            Responder.Instance.TutorialModel.Tutorialettes.Add(lesson1Data);
		}
	}
}
