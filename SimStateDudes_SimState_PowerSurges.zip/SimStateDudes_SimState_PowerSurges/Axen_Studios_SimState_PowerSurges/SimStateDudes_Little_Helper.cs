﻿/*
 * Created by SharpDevelop.
 * User: Nytician
 * Date: 20/02/2021
 * Time: 19:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Sims3.SimIFace;
using Sims3.Gameplay.Utilities;

namespace SimStateDudes_Little_Helper
{
	/// <summary>
	/// Description of Axens_Little_Helper.
	/// </summary>
	public static class Debug
	{
		public static bool ShowException(Exception exception)
		{
			try
			{
				return ((IScriptErrorWindow)AppDomain.CurrentDomain.GetData("ScriptErrorWindow")).DisplayScriptError(null, exception);
			}
			catch
			{
				WriteLog(exception);
				return true;
			}
		}

		public static bool WriteLog(Exception exception)
		{
			try
			{
				new ScriptError(null, exception, 0).WriteMiniScriptError();
				return true;
			}
			catch
			{
				return false;
			}
		}
	}
}
