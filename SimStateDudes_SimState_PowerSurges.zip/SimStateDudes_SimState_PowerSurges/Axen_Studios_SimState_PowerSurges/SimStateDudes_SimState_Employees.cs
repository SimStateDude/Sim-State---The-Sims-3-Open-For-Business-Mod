﻿using System;
using System.Collections.Generic;
using Sims3.SimIFace;
using Sims3.SimIFace.CAS;
using Sims3.UI;
using Sims3.Gameplay.Objects;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.CAS;
using Sims3.Gameplay.Core;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Situations;
using Sims3.Gameplay.Autonomy;
using Sims3.Gameplay.Utilities;
using Sims3.Gameplay.Interfaces;
using Sims3.Gameplay;
using Sims3.Gameplay.UI;

namespace SimStateDudes_SimState
{
	/// <summary>
	/// Description of SimStateDudes_SimState_Employees.
	/// </summary>
	public class Employees
	{
		
		public const int employeeMinimumWage = 10;
		public const int employeeChanceOfQuitting = 250;
		
		public Employees()
		{
			
		}
		
		public enum EmployeeRoles
		{
			Unassigned,
			StoreAssistant,
			Manager
		}
		
		public static string GetEmployeeRoleName(EmployeeRoles role)
		{
			
			if (role == EmployeeRoles.Manager)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Employees/GetEmployeeRole:Manager", new object[0]); 
			}
			else if (role == EmployeeRoles.StoreAssistant)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Employees/GetEmployeeRole:StoreAssistant", new object[0]);
			}
			else if (role == EmployeeRoles.Unassigned)
			{
				return Localization.LocalizeString("SimStateDudes/SimState/Employees/GetEmployeeRole:Unassigned", new object[0]);
			}
			return "";
		}
		
		public static void ManagePushEmployees()
		{
			//If the active sim is on the business lot and the business is open.
			foreach (KeyValuePair<ulong,Business_Save> business in Core.ownedBusinessdDict)
			{
				ulong lotID = business.Key;
				//Check if the business has any employees & if they are already on the lot or not.
				if (Core.ownedBusinessdDict[lotID].GetCurrentEmployees().Count > 0 && business.Value.GetBusinessOpenClose() == true)
				{
					foreach(KeyValuePair<SimDescription, Business_Employees> employee in Core.ownedBusinessdDict[lotID].GetCurrentEmployees())
					{
						Sim sim = SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId);
						//Push sim to do stuff if needs doing...
						if (!sim.IsInActiveHousehold)
						{
							Sim.RemoveGoHomeInteractions(sim,true);
						}
						
						//Ensure sim is on the lot and not 'sent home'.
						if (sim.LotCurrent.LotId == lotID && !employee.Value.GetEmployeeSentHome())
						{
							//ALL EMPLOYEES.
							if (CheckIfEmployedHere(lotID,sim))
							{
								//Add manage employee... options if not already got them!
								AddEmployeeInteractions(lotID);
								//Find any objects that need restocking if available and push to restock!
								foreach(KeyValuePair<ObjectGuid,ObjectForSale> obj in Core.ownedBusinessdDict[lotID].GetObjectsForSale())
								{
									//EMPLOYEES RESTOCK OBJECTS AUTONOMOUSLY.
									if (obj.Value.GetObjectSold() == true)
									{
										try
										{
											if (!sim.IsActiveSim && sim.InteractionQueue.Count < 1)
											{
												InteractionInstance interactionInstance = RestockObject.Singleton.CreateInstance(GameObject.GetObject(obj.Value.GetObjectID()), sim, new InteractionPriority(InteractionPriorityLevel.High), isAutonomous: false, cancellableByPlayer: true);
												sim.InteractionQueue.Add(interactionInstance);
												break;
											}
										}
										catch(Exception e)
										{
											SimStateDudes_Little_Helper.Debug.ShowException(e);
										}
									}
								}
							}
						}
						else if (!employee.Value.GetEmployeeSentHome())
						{
							try
							{
								//Call in all non-active family employees!
								CallInEmployees(lotID,sim,false);
							}
							catch(Exception e)
							{
								SimStateDudes_Little_Helper.Debug.ShowException(e);
							}
						}
					}
				}
			}
		}
		
		//Check if sim is employed in the chosen business and if they are the correct role.
		public static bool CheckIfEmployeeHasRole(ulong lotID, Sim sim, EmployeeRoles role)
		{
			if (Core.ownedBusinessdDict.ContainsKey(lotID) && Core.ownedBusinessdDict[lotID].GetCurrentEmployees().ContainsKey(sim.SimDescription) && Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[sim.SimDescription].GetEmployeeRole() == role)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		//Checks if a sim is employed in a specific business.
		public static bool CheckIfEmployedHere(ulong lotID, Sim sim)
		{
			if (Core.ownedBusinessdDict.ContainsKey(lotID) && Core.ownedBusinessdDict[lotID].GetCurrentEmployees().ContainsKey(sim.SimDescription))
			{
				return true;
			}
			return false;
		}
		
		//Checks if a sim is employed in any businesses.
		public static bool CheckIfEmployed(SimDescription desc)
		{
			foreach(KeyValuePair<ulong,Business_Save> business in Core.ownedBusinessdDict)
			{
				if (Core.ownedBusinessdDict[business.Key].GetCurrentEmployees().ContainsKey(desc))
				{
					return true;
				}
			}
			return false;
		}
		
		//Check how many managers work here.
		public static int CheckAmountOfManagers(ulong lotID)
		{
			int managerCount = 0;
			foreach(KeyValuePair<SimDescription,Business_Employees> employee in Core.ownedBusinessdDict[lotID].GetCurrentEmployees())
			{
				if (employee.Value.GetEmployeeRole() == EmployeeRoles.Manager)
				{
					managerCount++;
				}
			}
			
			return managerCount;
		}
		
		public static void CallInEmployees(ulong lotID, Sim sim, bool includeActive)
		{
			//Call in all employees who are not in the active household.
			if (!sim.IsInActiveHousehold || includeActive)
			{
				if (sim.LotCurrent.LotId != lotID)
				{
					sim.PushSwitchToOutfitInteraction(Sim.ClothesChangeReason.GoingToWork,OutfitCategories.Career);
					sim.InteractionQueue.CancelAllInteractions();
					
					InteractionInstance interactionInstance;
					
					//Use the Visit Lot interaction if its residential to ensure employees actually ring the bell and come in!
					if (LotManager.GetLot(lotID).IsCommunityLot)
					{
						interactionInstance = GoToLot.Singleton.CreateInstance(LotManager.GetLot(lotID), sim, new InteractionPriority(InteractionPriorityLevel.High), isAutonomous: false, cancellableByPlayer: true);
					}
					else
					{
						interactionInstance = VisitLot.Singleton.CreateInstance(LotManager.GetLot(lotID), sim, new InteractionPriority(InteractionPriorityLevel.High), isAutonomous: false, cancellableByPlayer: true);
					}
					
					sim.InteractionQueue.AddNext(interactionInstance);
					VisitSituation.OnInvitedIn(sim);
					if (!sim.IsSelectable)
					{
						GoInsideLotAndSocialize goInsideLotAndSocialize = GoInsideLotAndSocialize.Singleton.CreateInstance(Sim.ActiveActor, sim, new InteractionPriority(InteractionPriorityLevel.High), isAutonomous: false, cancellableByPlayer: true) as GoInsideLotAndSocialize;
						sim.InteractionQueue.Add(goInsideLotAndSocialize);
					}
				}
			}
		}
		
		public static void PayEmployeeCheck()
		{
			foreach(KeyValuePair<ulong,Business_Save> business in Core.ownedBusinessdDict)
			{
				//If business is open, check if the employees are on the business lot. If they are pay them from the business account!
				if (business.Value.GetBusinessOpenClose() == true)
				{
					foreach(KeyValuePair<SimDescription,Business_Employees> employee in Core.ownedBusinessdDict[business.key].GetCurrentEmployees())
					{
						//If the sim is on the same lot as the business they are employed in!
						if (SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId).LotCurrent.LotId == business.Key)
						{
							//Pay the employee!
							business.Value.RemoveFromBusinessAccount(employee.Value.GetEmployeeWagePerHour());
							SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId).ModifyFunds(employee.Value.GetEmployeeWagePerHour());
						}
					}
				}
			}
		}
		
		private static bool EmployeeChanceToQuit(ulong lotID, Sim actor)
		{
			if (Core.ownedBusinessdDict.ContainsKey(lotID))
			{
				if (Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeWagePerHour() < EmployeeExpectedWage(Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole()))
				{
					return true;					
				}
			}
			
			return false;
		}
		
		public static int EmployeeExpectedWage(EmployeeRoles role)
		{
			if (role == EmployeeRoles.StoreAssistant)
			{
				return 10;
			}
			
			if (role == EmployeeRoles.Manager)
			{
				return 20;
			}
			
			return employeeMinimumWage;
		}
		
		private static int GetSeverancePay(int shiftsWorked, EmployeeRoles role)
		{
			int pay = 0;
			
			pay += shiftsWorked * 10;
			
			if (shiftsWorked >= 50)
			{
				pay *= 2;
			}
			
			if (role == EmployeeRoles.StoreAssistant && shiftsWorked > 14)
			{
				pay += 500;
			}
			
			if (role == EmployeeRoles.Manager && shiftsWorked > 14)
			{
				pay += 2500;
			}
			
			return pay;
		}
		
		public static int GiveSeverancePay(ulong LotID, Sim actor)
		{
			int severancePay = GetSeverancePay(Core.ownedBusinessdDict[LotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeShiftsWorked(),Core.ownedBusinessdDict[LotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole());
			if (Core.ownedBusinessdDict.ContainsKey(LotID) && Core.ownedBusinessdDict[LotID].GetCurrentEmployees().ContainsKey(actor.SimDescription))
			{
				actor.ModifyFunds(severancePay);
				Core.ownedBusinessdDict[LotID].RemoveFromBusinessAccount(severancePay);
				
				return severancePay;
			}
			
			return 0;
		}
		
		public static void ShowEmployeeFiredMessage(ulong lotID, Sim actor)
		{
			SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:Fired", new object[] {actor.GetLocalizedName(),GetSeverancePay(Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeShiftsWorked(),Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole()).ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
		}
		
		public static void ShowEmployeeInfo(ulong lotID, Sim actor)
		{
			SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees:ShowEmployeeInfoTNS", new object[] {actor.GetLocalizedName(),GetEmployeeRoleName(Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole()),Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeWagePerHour().ToString(),actor.MoodManager.MoodFlavor.ToString(),Core.ownedBusinessdDict[lotID].GetCurrentEmployees()[actor.SimDescription].GetEmployeeShiftsWorked().ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
		}
		
		private static void ShowChangedRoleNotification(Sim actor)
		{
			SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangedRoleNotification:NewRole", new object[] {actor.GetLocalizedName(),GetEmployeeRoleName(Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole())}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
		}
		
		private static void ChangeEmployeeRole(Sim actor, EmployeeRoles role)
		{
			Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetCurrentEmployees()[actor.SimDescription].SetEmployeeRole(role);
			Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetCurrentEmployees()[actor.SimDescription].SetEmployeeWagePerHour(EmployeeExpectedWage(role));
		}
		
		public static bool CheckIfEmployeeCanRestock(Sim actor)
		{
			if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole() == EmployeeRoles.StoreAssistant)
			{
				return true;
			}
			else if (Core.ownedBusinessdDict[actor.LotCurrent.LotId].GetCurrentEmployees()[actor.SimDescription].GetEmployeeRole() == EmployeeRoles.Manager)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		public static void AddEmployeeInteractions(ulong lotID)
		{
			foreach(KeyValuePair<SimDescription,Business_Employees> employee in Core.ownedBusinessdDict[lotID].GetCurrentEmployees())
			{
				bool alreadyAdded = false;
				Sim sim = SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId);
				foreach (InteractionObjectPair interaction in sim.Interactions)
				{
					//Only check if they have the fire interaction and assume they have all the others too!
        			if (interaction.InteractionDefinition.GetType() == Fire.Singleton.GetType())
					{
        				alreadyAdded = true;
						break;
        			}
				}
				
				if (alreadyAdded == false)
				{
					sim.AddInteraction(Fire.Singleton);
					sim.AddInteraction(SendHome.Singleton);
					
					sim.AddInteraction(RoleStoreAssistant.Singleton);
					sim.AddInteraction(RoleManager.Singleton);
					
					sim.AddInteraction(EmployeeInfo.Singleton);
					sim.AddInteraction(ChangeWage.Singleton);
					sim.AddInteraction(ChangeUniform.Singleton);
					sim.AddInteraction(ChangeIntoUniform.Singleton);
				}
			}
		}
		
		//Remove interactions from employees, or a specific employee.
		public static void RemoveEmployeeInteractions(ulong lotID, SimDescription desc)
		{
			foreach(KeyValuePair<SimDescription,Business_Employees> employee in Core.ownedBusinessdDict[lotID].GetCurrentEmployees())
			{
				Sim sim = SimDescription.GetCreatedSim(employee.Value.GetSimDescription().SimDescriptionId);
				if (desc == null)
				{
					bool alreadyRemoved = true;
					foreach (InteractionObjectPair interaction in sim.Interactions)
					{
						//Only check if they have the fire interaction and assume they have all the others too!
						if (interaction.InteractionDefinition.GetType() == Fire.Singleton.GetType())
						{
							alreadyRemoved = false;
							break;
						}
					}
					
					if (alreadyRemoved == false)
					{
						sim.RemoveInteractionByType(Fire.Singleton);
						sim.RemoveInteractionByType(SendHome.Singleton);
						
						sim.RemoveInteractionByType(RoleStoreAssistant.Singleton);
						sim.RemoveInteractionByType(RoleManager.Singleton);
						
						sim.RemoveInteractionByType(EmployeeInfo.Singleton);
						sim.RemoveInteractionByType(ChangeWage.Singleton);
						sim.RemoveInteractionByType(ChangeUniform.Singleton);
						sim.RemoveInteractionByType(ChangeIntoUniform.Singleton);
					}
				}
				else if (desc == employee.Value.GetSimDescription())
				{
					bool alreadyRemoved = true;
					foreach (InteractionObjectPair interaction in sim.Interactions)
					{
						//Only check if they have the fire interaction and assume they have all the others too!
						if (interaction.InteractionDefinition.GetType() == Fire.Singleton.GetType())
						{
							alreadyRemoved = false;
							break;
						}
					}
					
					if (alreadyRemoved == false)
					{
						sim.RemoveInteractionByType(Fire.Singleton);
						sim.RemoveInteractionByType(SendHome.Singleton);
						
						sim.RemoveInteractionByType(RoleStoreAssistant.Singleton);
						sim.RemoveInteractionByType(RoleManager.Singleton);
						
						sim.RemoveInteractionByType(EmployeeInfo.Singleton);
						sim.RemoveInteractionByType(ChangeWage.Singleton);
						sim.RemoveInteractionByType(ChangeUniform.Singleton);
						sim.RemoveInteractionByType(ChangeIntoUniform.Singleton);
					}
					break;
				}
			}
		}
		
		//CHANGE UNIFORM.
		public class ChangeUniform : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, ChangeUniform>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeUniform:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[2] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/Employees/UniformPath:InteractionName", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				CASLogic singleton = CASLogic.GetSingleton();
				
				singleton.LoadSim(base.Target.SimDescription,base.Target.CurrentOutfitCategory,base.Target.CurrentOutfitIndex);
				singleton.UseTempSimDesc = true;
				
				GameStates.TransitionToCASDresserMode();
				
				base.Target.InteractionQueue.CancelAllInteractions();
				base.Target.PushSwitchToOutfitInteraction(Sim.ClothesChangeReason.GoingToWork,OutfitCategories.Career);
				
				HudModel hudModel = Sims3.UI.Responder.Instance.HudModel as HudModel;
				hudModel.NotifySimChanged(Target.ObjectId);
				return true;
			}
		}
		
		//CHANGE WORK OUTFIT.
		public class ChangeIntoUniform : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, ChangeIntoUniform>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeIntoUniform:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[2] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/Employees/UniformPath:InteractionName", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager) || a.SimDescription == target.SimDescription)
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				base.Target.InteractionQueue.CancelAllInteractions();
				base.Target.PushSwitchToOutfitInteraction(Sim.ClothesChangeReason.GoingToWork,OutfitCategories.Everyday);
				base.Target.PushSwitchToOutfitInteraction(Sim.ClothesChangeReason.GoingToWork,OutfitCategories.Career);
				return true;
			}
		}
		
		//FIRE!
		public class Fire : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, Fire>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[1] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				//Don't allow all managers to be fired!
				if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
				{
					
					if (Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[base.Target.SimDescription].GetEmployeeRole() != EmployeeRoles.Manager || Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[base.Target.SimDescription].GetEmployeeRole() == EmployeeRoles.Manager && CheckAmountOfManagers(base.Target.LotCurrent.LotId) > 1)
					{
						//Check if the business lot is owned by them if a manager.
						if(base.Target.LotCurrent.LotId != base.Target.LotHome.LotId)
						{
							//Remove sim from employee dictionary and send home!
							//Relationship hit between employee and employer.
							if (base.Actor != base.Target)
							{
								base.Target.GetRelationship(base.Actor,true).LTR.SimWasBetrayed(base.Actor);
								base.Target.GetRelationship(base.Actor,true).LTR.SetLiking(-30);
								base.Actor.GetRelationship(base.Target,true).LTR.SimWasBetrayed(base.Target);
								base.Actor.GetRelationship(base.Target,true).LTR.SetLiking(-30);
							}
							
							ShowEmployeeFiredMessage(base.Target.LotCurrent.LotId,base.Target);
							GiveSeverancePay(base.Target.LotCurrent.LotId, base.Target);
							RemoveEmployeeInteractions(base.Target.LotCurrent.LotId,base.Target.SimDescription);
							Sim.MakeSimGoHome(base.Target,false);
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees().Remove(base.Target.SimDescription);
						}
						else if (!CheckIfEmployeeHasRole(base.Target.LotCurrent.LotId,base.Target, EmployeeRoles.Manager))
						{
							if (base.Actor != base.Target)
							{
								base.Target.GetRelationship(base.Actor,true).LTR.SimWasBetrayed(base.Actor);
								base.Target.GetRelationship(base.Actor,true).LTR.SetLiking(-30);
								base.Actor.GetRelationship(base.Target,true).LTR.SimWasBetrayed(base.Target);
								base.Actor.GetRelationship(base.Target,true).LTR.SetLiking(-30);
							}
							
							ShowEmployeeFiredMessage(base.Target.LotCurrent.LotId,base.Target);
							GiveSeverancePay(base.Target.LotCurrent.LotId, base.Target);
							RemoveEmployeeInteractions(base.Target.LotCurrent.LotId,base.Target.SimDescription);
							Sim.MakeSimGoHome(base.Target,false);
							Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees().Remove(base.Target.SimDescription);
						}
						else
						{
							SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:YouCannotFireHouseholdManagers", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
						}
					}
					else
					{
						//You can't fire all the managers!
						SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:YouCannotFireAllManagers", new object[0]),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
					}
				}
				return true;
			}
		}
		
		public class SendHome : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, SendHome>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/SendHome:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[1] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				//Send home the current employee...
				if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId))
				{
					//Set to 'sent home' in employee status so not recalled by manage employee event check.
					Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[base.Target.SimDescription].SendEmployeeHome();
					base.Target.InteractionQueue.CancelAllInteractions();
					Sim.MakeSimGoHome(base.Target, false);
					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/SendHome:SimSentHome", new object[] {base.Target.GetLocalizedName().ToString()} ),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
				}
				return true;
			}
		}
		
		//ROLES!
		//STORE ASSISTANT.
		public class RoleStoreAssistant : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, RoleStoreAssistant>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/RoleStoreAssistant:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[2] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:ChangeRole", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				if (base.Actor != base.Target || CheckAmountOfManagers(base.Target.LotCurrent.LotId) > 1)
				{
					//Change role.
					ChangeEmployeeRole(base.Target,EmployeeRoles.StoreAssistant);
					//Show changed role notification.
					ShowChangedRoleNotification(base.Target);
				}
				else
				{
					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/Fire:YouCannotFireAllManagers", new object[0] ),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
				}
				return true;
			}
		}
		
		public class RoleManager : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, RoleManager>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/RoleManager:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[2] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:ChangeRole", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				//Change role.
				ChangeEmployeeRole(base.Target,EmployeeRoles.Manager);
				//Show changed role notification.
				ShowChangedRoleNotification(base.Target);
				return true;
			}
		}
		
		public class EmployeeInfo : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, EmployeeInfo>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/ShowEmployeeInfo:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[1] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (Core.ownedBusinessdDict.ContainsKey(a.LotCurrent.LotId) && Core.ownedBusinessdDict[a.LotCurrent.LotId].GetCurrentEmployees().ContainsKey(a.SimDescription))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YouDontWorkHere", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				//Show employee info dialog.
				ShowEmployeeInfo(base.Target.LotCurrent.LotId, base.Target);
				return true;
			}
		}
		
		//Allow the user to change the employees wage!
		public class ChangeWage : ImmediateInteraction<Sim, Sim>
		{
			private sealed class Definition : ImmediateInteractionDefinition<Sim, Sim, ChangeWage>
			{
				public override string GetInteractionName(Sim a, Sim target, InteractionObjectPair interaction)
				{
					return Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeWage:InteractionName", new object[0]);
				}
				
				public override string[] GetPath(bool isFemale)
				{
					return new string[1] {Localization.LocalizeString("SimStateDudes/SimState/Employees/ManageEmployeePath:InteractionName", new object[0])};
				}

				public override bool Test(Sim a, Sim target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
				{
					isAutonomous = false;
					if (CheckIfEmployeeHasRole(target.LotCurrent.LotId,a, EmployeeRoles.Manager))
					{
						return true;
					}
					else
					{
						greyedOutTooltipCallback = CreateTooltipCallback(Localization.LocalizeString("SimStateDudes/SimState/Business:YourNotAManager", new object[0]));
						return false;
					}
				}
			}

			public static readonly InteractionDefinition Singleton = new Definition();

			public override bool Run()
			{
				//Allow the user to change the employees wage.
				string changeWage = StringInputDialog.Show(Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeWage:DialogTitle", new object[0]),Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeWage:DialogSubTitle", new object[0]),"",true);
				int result;
				int.TryParse(changeWage, out result);
				if (result < employeeMinimumWage)
				{
					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeWage:BelowMinimumWage", new object[] {employeeMinimumWage.ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
				}
				else
				{
					SimStateDudes_SimState.Core.StyledNotification.Show(new SimStateDudes_SimState.Core.StyledNotification.Format(Localization.LocalizeString("SimStateDudes/SimState/Employees/ChangeWage:NewWageSet", new object[] {base.Target.GetLocalizedName(), result.ToString()}),SimStateDudes_SimState.Core.StyledNotification.NotificationStyle.kSystemMessage),"Sim_State_Notification");
				}
				
				if (Core.ownedBusinessdDict.ContainsKey(base.Target.LotCurrent.LotId) && Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees().ContainsKey(base.Target.SimDescription))
				{
					Core.ownedBusinessdDict[base.Target.LotCurrent.LotId].GetCurrentEmployees()[base.Target.SimDescription].SetEmployeeWagePerHour(result);
				}
				return true;
			}
		}
	}
}
